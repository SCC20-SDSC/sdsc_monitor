from __future__ import absolute_import, print_function

import sys
import os.path
import time
import getpass
import logging
import traceback
import copy
from collections import OrderedDict
from optparse import OptionParser

from six.moves import configparser
from six.moves import urllib
import urllib3
from cyclecli import util
from cyclecli.datastore import RestDatastore
from cyclecli import config_manager

from cyclecli.version import __version__

logging.basicConfig(level=logging.WARN)
logger = logging.getLogger(__name__)

# we disable this because we confirm the security issue with the user in advance
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_config_file = os.path.expanduser(os.path.join("~", ".cycle", "config.ini"))
_registered_commands = {}
_deprecated_commands = {}
_command_aliases = {}
_registered_config_sections = OrderedDict()
_application_name = "Unknown"
_version = "Unknown"

_requires_cycleserver = True  # By default, CLIs expect the cycleserver config section

_deprecated_config_paths = [os.path.expanduser(os.path.join("~", ".cyclecloud", "config")), 
                            os.path.expanduser(os.path.join("~", ".cycle", "config"))]

USAGE_TEMPLATE = "%%prog %s %s [options]"


class CaseInsensitiveList(list):
    def __contains__(self, string):
        return string.lower() in (n.lower() for n in self)

YES_NO_SET = CaseInsensitiveList(["yes", "y", "no", "n"])
YES_SET = CaseInsensitiveList(["yes", "y"])

    
def run(args, allow_unknown_args=False, exit_on_failure=True, app_name=_application_name, version=_version, config_file=_config_file):
    '''Run method that should be used by most Cycle command-line tools after registering
    commands and config sections.

    Sample Usage:
    if __name__ == "__main__":
        register_commands()
        register_config_sections()
        run(sys.argv[1:])
    '''
    try:
        _run(args, allow_unknown_args=allow_unknown_args, exit_on_failure=exit_on_failure, app_name=app_name, version=version, config_file=config_file)
    except KeyboardInterrupt:
        logger.warn("Canceled")


def prompt(s="", password=False, valid_selections=[], default_value=None, required=False):
    '''Helper method for prompting the user for input with various expectations.'''
    if not s.endswith(" "):
        # Make sure there's always a space before the prompt
        s += " "

    if password:  # passwords should never have expected valid selection lists...
        valid_selections = []

    if default_value:
        if not password:
            s = "%s[%s] " % (s, default_value)
        else:
            s = "%s[********] " % s

    if default_value and valid_selections and default_value not in valid_selections:
        valid_selections.insert(0, default_value)

    while True:
        if password and os.isatty(sys.stdin.fileno()):
            v = getpass.getpass(s)
        else:
            sys.stdout.write(s)
            sys.stdout.flush()
            v = sys.stdin.readline().rstrip("\r\n")

        if not v:
            v = default_value or ""

        if not v and required:
            sys.stdout.write("A value is required.\n")
            sys.stdout.flush()
            continue
        elif v and valid_selections and v not in valid_selections:
            sys.stdout.write("Invalid selection, valid choices: (%s)\n" % ", ".join(valid_selections))
            sys.stdout.flush()
            continue
        else:
            break

    return v


def getLogger(name=None):
    if name:
        return logging.getLogger('%s.%s' % (__name__, name))
    else:
        return logging.getLogger(__name__)


class ArgumentError(Exception):
    pass

class UnknownCommandError(Exception):
    pass


class ConfigError(Exception):
    pass


class UserError(Exception):
    def __init__(self, message, code=None):
        super(UserError, self).__init__(message)
        self.code = code


class BaseCommand(object):
    '''Base class for command line sub-commands'''

    def _configure(self, parser):
        args_string = getattr(self, "args", "")

        parser.usage = (USAGE_TEMPLATE % (self.command, args_string)).replace("  ", " ")

        parser.description = getattr(self, "description", "")
        if hasattr(self, 'aliases'):
            parser.description = "%s Aliases: %s" % (parser.description, ", ".join(self.aliases))

        self.configure(parser)

    def configure(self, parser):
        pass

        
class ConfigCommand(BaseCommand):

    def __init__(self, config_file=None, application_name=None, identifying_section=None,
                 identifying_keyword=None):
        self.args = '<command>'
        self.application_name = application_name or _application_name
        config_file = config_file or _config_file
        cycle_homedir = os.path.expanduser("~/.cycle")
        self.config_props = config_manager.ConfigProperties(cycle_homedir, config_file,
                                                            self.application_name.lower())

        self.description = 'Easily switch between %s configurations' % application_name.lower()
        self.usage = '''
%s config <command> [options]

Valid commands are:
show                          show the current configuration in use
list                          list available configurations
create <config_name>          create a new configuration
rename <old_name> <new_name>  rename an existing configuration
use <config_name>             switch to a specified configuration
remove <config_name>          remove a named configuration
        ''' % self.application_name.lower()
        self.commands = ['list', 'rename', 'show', 'use', 'create', 'remove']

    def configure(self, parser):
        parser.remove_option('--config')
        parser.set_usage(self.usage.strip())

    def check_for_min_arguments(self, arguments):
        if len(arguments) < 1:
            print((self.usage))
            raise UserError('Please enter a valid subcommand for \'%s config\'' % self.application_name.lower())

    def check_valid_subcommand(self, command):
        if command not in self.commands:
            print((self.usage))
            raise UserError('%s is not a valid subcommand, valid commands for \'%s config\' are %s' %
                            (command, self.application_name.lower(), ', '.join(self.commands)))

    def execute(self, options, arguments):
        self.check_for_min_arguments(arguments)
        command = arguments[0].strip()
        args = arguments[1:]
        self.check_valid_subcommand(command)
        require_one_arg = util.make_only_one_arg_function(self.application_name)

        if command == 'rename':
            if len(args) != 2:
                raise UserError("the rename operation requires <old_name> <new_name> arguments")
            old_name, new_name = args
            config_manager.rename(self.config_props, old_name, new_name)
        elif command == 'remove':
            require_one_arg(args, "remove")
            config_manager.delete_config(self.config_props, args[0])
        elif command == 'show':
            config_manager.show(self.config_props)
        elif command == 'list':
            config_manager.list_configurations(self.config_props)
        elif command == 'use':
            require_one_arg(args, "use")
            config_manager.use(self.config_props, args[0])
        elif command == 'create':
            require_one_arg(args, "create")
            config_name = args[0]
            config_manager.validate_config_name(config_name)
            initialize(application_name=self.application_name, options=options,
                       welcome_msg="Configuring %s" % self.application_name,
                       force_reconfig=True, named_config=config_name)
        else:
            print((self.usage))
            raise UserError('Command provided %s is invalid' % command)


class ConfigSection(object):
    '''Parses a single section (or sub-section) of the cycle config file.

    By default, the section will be added as a sub-dictionary to the global config under
    key==section.name. Example::

        config[section.name] = { 'local_config': 'value' }

    If update_global_namespace is set to True, then the config values will ALSO be merged into
    the top-level/global config settings (Use with caution...).
    Example with section.update_global_namespace = True::

        config['local_config'] = 'value'
        config[section.name] = { 'local_config': 'value' }

    '''

    def __init__(self, section_name, update_global_namespace=False, section_required=True):
        self._name = section_name
        self._config = {}
        self._update_global_namespace = update_global_namespace
        self._section_required = section_required

    def read(self, parser):
        '''Reads the section from the config parser and returns as a dictionary.'''
        return self.config

    def config_batch(self, parser, config, options):
        '''Reads the parameters for values and stores them to the parser.
        There is no user, so there should be no display and questions should
        be answered in the default. If there is no default then it should fail.'''
        raise NotImplementedError("Batch mode is not supported.")

    def config_wizard(self, parser, config):
        '''
        Queries the user for section config values and stores them to the parser.
        Takes a ConfigParser and a config dictionary which contains all of the config
        values read so far.
        '''
        pass

    @property
    def name(self):
        return self._name

    @property
    def config(self):
        return self._config

    @property
    def update_global_namespace(self):
        return self._update_global_namespace

    @property
    def section_required(self):
        return self._section_required


def set_requires_cycleserver(required=True):
    '''Configures whether CLI registers the cycleserver config section (default: True)'''
    global _requires_cycleserver
    _requires_cycleserver = required


def requires_cycleserver():
    global _requires_cycleserver
    return _requires_cycleserver


def register_commands(commands):
    '''Add a set of handlers for command-line sub-commands.
    
    commands maps the command-line name to the Command object
    ex. { "foo" : FooCommand }
    '''
    global _registered_commands

    for cmd_name, command in commands.items():
        # lowercase all the commands, we'll just make commands case insensitive
        cmd_name = cmd_name.lower() 
        if cmd_name in _registered_commands:
            logger.warn("Duplicate definitions registered for command: %s" % cmd_name)
        command.command = cmd_name
        _registered_commands[cmd_name] = command
        _command_aliases[cmd_name] = [a.lower() for a in getattr(command, "aliases", [])]


def deprecate_commands(commands):
    '''Helper that maps a set of deprecated command names to the current replacement command
    names.

    ex. commands = { "old_foo" : "new_foo" }
    IMPORTANT:
    Only use this helper if the new command takes the same arguments in the same order.
    '''
    global _deprecated_commands

    for old_name, new_name in commands.items():
        old_name = old_name.lower()
        new_name = new_name.lower()
        if old_name in _registered_commands:
            logger.warn("Duplicate deprecations registered for command: %s (%s, %s)" % (old_name, new_name, _registered_commands[old_name]))
        _deprecated_commands[old_name] = new_name


def register_config_section(config_section):
    '''Add a handler for a new top-level config file section.'''
    global _registered_config_sections    
    
    section_name = config_section.name
    origina_sections = OrderedDict(_registered_config_sections)
    _registered_config_sections.clear()
    _registered_config_sections[section_name] = config_section
    _registered_config_sections.update(origina_sections)


def configure_initialize(parser, cs_name='CycleServer'):
    parser.add_option("--batch", dest="batch", action="store_true",
                      help="If specified, the arguments must be supplied on the command line. Questions will be assumed to be 'no'.")
    parser.add_option("--force", dest="force", action="store_true", default=False,
                  help="Force a re-initialize even if valid config file is available.")
    parser.add_option("--url", dest="url",
                      help="The base URL for the %s install." % cs_name)
    parser.add_option("--username", dest="username",
                      help="The username for the %s install." % cs_name)
    parser.add_option("--password", dest="password",
                      help="The password for the %s install." % cs_name)
    parser.add_option("--verify-ssl", dest="verify-ssl", default="true",
                      help="Whether to verify (true) or not (false) SSL certificates for the %s install." % cs_name)
    named_config_help = "Create a named configuration that can be used with the config command"
    parser.add_option("--name", dest="named_config", help=named_config_help, default=None)


def initialize(config_file=None,
               application_name=None, welcome_msg=None,
               options=None, force_reconfig=False, named_config=None):
    '''Initialize the cycle config file if it does not already exist.
    options: a dictionary of options, already set. The value of options.batch Indicates we are in batch mode.
    '''
    if config_file is None:
        # use the global default
        config_file = _config_file
    else:
        # HACK : Remove this as soon as we fix explicit config_file to work
        # HACK : with Named configs!!
        # For now, set config name to NONE to use using a non-standard config file
        named_config = None

    if not application_name:
        application_name = _application_name

    # if the config name is not specified, check if there is one currently set
    # otherwise use 'default'
    if named_config is None:
        current_config_name = config_manager.get_current_config_name(config_file, application_name)
        if current_config_name:
            named_config = current_config_name
        else:
            named_config = 'default'

    # If this CLI connects to CycleServer, add the CycleServer config section
    if requires_cycleserver():
        section = "cycleserver"
        if config_file in _deprecated_config_paths:
            section = "server"
        register_config_section(CycleServerSection(section))

    config = None
    try:
        config = parse_config_file(config_file=config_file)
    except ConfigError:
        config = None

    if not force_reconfig and config is not None:
        print("%s is configured properly." % application_name)
        # nothing more to do
        return

    if not os.path.exists(config_file) and options and vars(options).get('batch', False):
        if welcome_msg:
            print("%s" % welcome_msg)
        else:
            print("Welcome to %s!" % application_name)

    _initialize_config(config_file=config_file, application_name=application_name,
                       options=options, named_config=named_config)

    global _loaded_config
    _loaded_config = None

# Stores persistent over-rides of config values from file
_global_config_updates = None
_loaded_config = None


def update_config(config):
    '''Updates the global config with the changes specified in the provided dictionary.

    Updates are persistent and future calls to get_config will reflect them.
    '''
    global _global_config_updates
    if _global_config_updates is None:
        _global_config_updates = {}
    _global_config_updates.update(config)


def get_config(config_file=None):
    '''Get the current cycle configuration.  Returns None if not yet initialized.
    
    By default, the basic CycleServer URL and login info are parsed out.  Applications
    are expected to provide a specific config parser callable to handle specific 
    configuration:

    final_config = config_reader(config, parser [, args]) 
    '''
    global _global_config_updates

    if _loaded_config is None:
        load_config(config_file=config_file)
    config = copy.deepcopy(_loaded_config)

    # Now apply any programmatic updates
    if _global_config_updates is not None:
        config.update(_global_config_updates)

    return config


def load_config(config_file=None):
    global _loaded_config
    _loaded_config = parse_config_file(config_file)


def get_session(config=None, use_config_url=False):
    '''Get a connected session to CycleServer'''
    from requests.exceptions import SSLError

    if not config:
        config = get_config()

    s = None
    retries = 3
    while retries > 0:
        try:
            s = _get_session(config)

            for attr_name in ["request"]:
                attr = getattr(s, attr_name)
                setattr(s, attr_name, _wrap_request_function(attr, config, use_config_url))

            break
        except SSLError:
            retries = retries - 1
            if retries < 1:
                raise

    return s


def _wrap_request_function(f, config, use_config_url):
    from requests.exceptions import ConnectionError

    def wrapped(*args, **kwargs):
        if use_config_url:
            if "url" in kwargs:
                kwargs["url"] = config["url"] + kwargs["url"]
            else:
                url_index = 1
                args = list(args)
                args[url_index] = config["url"] + args[url_index]
                args = tuple(args)

        try:
            res = f(*args, **kwargs)
        except ConnectionError:
            raise UserError("Unable to connect to %s!" % _application_name)

        if hasattr(res, "status_code") and res.status_code == 401:
            raise UserError("Invalid username or password given. Please reinitialize by running: \n %s initialize --force" % sys.argv[0], code=res.status_code)

        if 400 <= res.status_code < 500:
            if res.text:
                raise UserError(res.text, code=res.status_code)
            else:
                raise UserError("Unspecified Error (%s)" % res.status_code, code=res.status_code)

        res.raise_for_status()

        return res

    for attr_name in dir(f):
        if attr_name not in dir(wrapped):
            attr = getattr(f, attr_name)
            setattr(wrapped, attr_name, attr)

    return wrapped


def get_datastore(config=None):
    if not config:
        config = get_config()

    return RestDatastore(config['url'], get_session(config))


class CycleServerSection(ConfigSection):

    def __init__(self, section_name="cycleserver"):
        super(CycleServerSection, self).__init__(section_name, update_global_namespace=True)

    def read(self, parser):
        self.config["url"] = parser.get(self.name, "url")
        if self.config["url"].endswith('/'):
            self.config["url"] = self.config["url"].rstrip('/')
        self.config["username"] = parser.get(self.name, "username")
        self.config["password"] = util.decode(parser.get(self.name, "key"))
        self.config["timeout"] = 60
        if parser.has_option(self.name, "timeout"):
            self.config["timeout"] = parser.getint(self.name, "timeout")
        self.config["verify_certificates"] = True
        if parser.has_option(self.name, "verify_certificates"):
            self.config["verify_certificates"] = parser.get(self.name, "verify_certificates").lower() in ["true"]
        elif parser.has_option(self.name, "verify"):
            self.config["verify_certificates"] = parser.get(self.name, "verify").lower() in ["true"]

        return self.config

    def config_batch(self, parser, config, options):
        if not parser.has_section(self.name):
            parser.add_section(self.name)

        url = self._get_required(options, "url")
        username = self._get_required(options, "username")
        password = self._get_required(options, "password")
        verify_ssl = getattr(options, "verify-ssl", "").lower() in ["true"]

        self._check_cs(url, username, password, verify_ssl)

        parser.set(self.name, 'url', url)
        parser.set(self.name, 'verify_certificates', str(verify_ssl).lower())
        parser.set(self.name, 'username', username)
        parser.set(self.name, 'key', util.encode(password))

    def _get_required(self, options, name):
        value = getattr(options, name)
        if value is None:
            raise UserError("The %s argument is required." % name)
        return value

    def config_wizard(self, parser, config):
        from requests.exceptions import ConnectionError, SSLError

        if not parser.has_section(self.name):
            parser.add_section(self.name)

        url = ""


        default_url = parser.get(self.name, 'url') if parser.has_option(self.name, 'url') else "http://localhost"
        while True:
            url = prompt('CycleServer URL: [%s] ' % default_url)
            if not url:
                url = default_url
            else:
                default_url = url

            try:
                r = None
                try:
                    if not url.startswith("http"):
                        url = "http://" + url

                    s = _get_session()
                    r = s.get(url)
                    parser.set(self.name, 'verify_certificates', 'true')
                    config['verify_certificates'] = True
                except SSLError:
                    default_ignore = 'yes' if not config.get('verify_certificates', False) else 'no'
                    ignoreSslError = prompt('Detected untrusted certificate.  Allow?: [%s] ' % default_ignore)
                    if not ignoreSslError:
                        ignoreSslError = default_ignore
                    if ignoreSslError.lower() in ['yes', 'y']:
                        parser.set(self.name, 'verify_certificates', 'false')
                        config['verify_certificates'] = False
                        s = _get_session({"verify_certificates": False})
                        r = s.get(url)
                        if r.status_code == 200:
                            url = _normalize_url(url, r.url)
                            break
                    else:
                        parser.set(self.name, 'verify_certificates', 'true')
                        config['verify_certificates'] = True
                        raise

                if r.status_code == 200:
                    url = _normalize_url(url, r.url)
                    break

                raise ConnectionError("Status code %s" % r.status_code)
            except ConnectionError as e:
                logger.error("CycleServer does not appear to be running at %s.\nError was: %s", url, str(e))

        parser.remove_option(self.name, 'verify') # this removes the old 'verify' setting to avoid confusing the user


        parser.set(self.name, 'url', url)

        user = ""
        password = ""

        while True:
            default_user = parser.get(self.name, 'username') if parser.has_option(self.name, 'username') else getpass.getuser()
            user = prompt('CycleServer username: [%s] ' % default_user)
            if not user:
                user = default_user

            password = prompt("CycleServer password: ", password=True)

            try:
                self._check_cs(url, user, password, config['verify_certificates'])
                # success
                break
            except ValueError as e:
                logger.error("%s, please try again", e)

        print("\nGenerating CycleServer key...")
        time.sleep(0.5)
        key = util.encode(password)

        parser.set(self.name, 'username', user)
        parser.set(self.name, 'key', key)

    def _check_cs(self, url, user, password, verify_ssl):
        s = _get_session({"username": user, "password": password, "verify_certificates": verify_ssl})

        r = s.get("%s/db/component?format=text" % url)
        if r.status_code == 401:
            raise ValueError("Invalid username/password")
        elif r.status_code != 200:
            raise ValueError("Unknown error (status code %s)" % r.status_code)


def find_config_file(config_file=None):
    config_file = config_file or _config_file
    config_file = os.path.expanduser(config_file)
    found = os.path.exists(config_file)
    if not found:

        # try other deprecated paths
        for f in _deprecated_config_paths:
            if os.path.exists(os.path.expanduser(f)):
                logger.warn("Config location \"%s\" is Deprecated.\n\tThe standard location is ~/.cycle/config.ini.", f)
                config_file = os.path.expanduser(f)
                found = True

        if not found:
            raise ConfigError("Configuration file not found.  (Expected path: %s)" % config_file)

    return config_file


def _get_config(config_file=None):
    '''Deprecated: use parse_config_file instead'''
    return parse_config_file(config_file)


def parse_config_file(config_file=None):
    try:
        config_file = find_config_file(config_file)

        # If this CLI connects to CycleServer, add the CycleServer config section
        if requires_cycleserver():
            section = "cycleserver"
            if config_file in _deprecated_config_paths:
                section = "server"
            register_config_section(CycleServerSection(section))

        p = configparser.RawConfigParser()
        p.read(config_file)

        for _, section in _registered_config_sections.items():
            if section.section_required and not p.has_section(section.name):
                raise ConfigError("Found incomplete configuration file (missing %s)." % section.name)

        return _build_config_dict(p) 
        
    except ConfigError:
        raise
    except Exception as e:
        raise ConfigError("Failed to parse config file %s:\n%s" % (config_file, str(e)))


def _build_config_dict(parser):
    '''
    Build a config dictionary with the current values of all config sections
    '''

    config = {}

    for _, section in _registered_config_sections.items():
        if parser.has_section(section.name):
            section.read(parser)
        
        section_content = section.config
        if section.update_global_namespace:
            config.update(section_content)
        config[section.name] = section_content

    # Add any unregistered sections to the config raw
    for section_name in parser.sections():
        if section_name not in _registered_config_sections:
            section = {}
            for option in parser.options(section_name):
                section[option] = parser.get(section_name, option)
            config[section_name] = section

    return config


def _initialize_config(config_file, application_name, options, named_config=None):
    config_file = os.path.abspath(os.path.expanduser(config_file))
    basedir = os.path.dirname(config_file)
    target_config = os.path.basename(config_file)
    config = configparser.RawConfigParser()

    if os.path.exists(config_file):
        # Initialize defaults from previous config
        print("Re-initializing. (Note: Current settings may be modified.)")
        config.read(config_file)

    # Now handle application specific parameters
    global _registered_config_sections    
    for _, section in _registered_config_sections.items():
        # Update the config dictionary each time a wizard runs
        config_dict = _build_config_dict(config)
        if options is not None and vars(options).get('batch', False):
            section.config_batch(config, config_dict, options)
        else:
            section.config_wizard(config, config_dict)

    util.make_missing_parent_dir(config_file)

    if named_config is None:
        logger.debug("Using nonstandard location %s for configuration", config_file)
        util.write_config_to_file(config_file, config)
    else:
        config_content = util.convert_config_parser_to_str(config)
        config_props = config_manager.ConfigProperties(basedir, target_config, application_name.lower())
        config_manager.make_and_use_config(config_props, named_config, config_content)

    print("%s configuration stored in %s" % (application_name, config_file))


def _normalize_url(original_url, final_url):
    '''Determines the URL to use in part by the url after redirects'''
    final_parsed = urllib.parse.urlparse(final_url)
    # note: we ignore the path (just the scheme and host/port). This is because
    # the site might redirect to /home or something, and that's not the real path to use.
    url = "%s://%s" % (final_parsed.scheme, final_parsed.netloc)

    original_parsed = urllib.parse.urlparse(original_url)
    if original_parsed.path != "":
        # if the original value from the user had a path, we do include that
        url += original_parsed.path

    url = url.rstrip('/')
    
    if url != original_url:
        print("Using", url)
        
    return url
    

def _get_session(config=None):
    import requests

    if config is None:
        config = {}

    if not config.get("verify_certificates", True):
        urllib3.disable_warnings()

    s = requests.session()
    if "username" in config and "password" in config:
        s.auth = (config["username"], config["password"])
    if "timeout" in config.get("cycleserver", {}):
        s.timeout = config["cycleserver"]["timeout"]
    s.verify = config.get("verify_certificates", True)
    s.headers = {"X-Cycle-Client-Version": "cyclecloud-cli:%s" % _version,
                 "User-Agent": "CycleCloudCli/%s" % _version}

    return s


class PassThroughOptionParser(OptionParser):
    """    
    If allow_unknown_args==True, then append options that are not explicitly handled as args.
    This is useful for CLIs like submitonce which may pass a list of arguments to CLIs for 
    other systems.   

    When unknown arguments are encountered, bundle with largs and try again,
    until rargs is depleted.  

    If a known argument is passed incorrectly (e.g. missing arguments or bad argument types, etc.)
    the normal OptionParser handling still applies.
    
    @see http://stackoverflow.com/questions/1885161/how-can-i-get-optparses-optionparser-to-ignore-invalid-options        
    """
    def __init__(self, allow_unknown_args=False, *args, **kwargs):
        self.allow_unknown_args = allow_unknown_args
        OptionParser.__init__(self, *args, **kwargs)

    def _process_args(self, largs, rargs, values):
        from optparse import (OptionParser, BadOptionError, AmbiguousOptionError)        
        while rargs:            
            try:
                OptionParser._process_args(self, largs, rargs, values)
            except (BadOptionError, AmbiguousOptionError) as e:
                if self.allow_unknown_args:
                    largs.append(e.opt_str)
                else:
                    raise

    def print_help(self, append_command_list=True):
        OptionParser.print_help(self)

        if append_command_list:
            min_width = 0
            command_list = list(_registered_commands.keys())
            command_list.sort()

            for name in command_list:
                if len(name) > min_width:
                    min_width = len(name)

            print("")
            print("Commands:")
            for name in command_list:
                c = _registered_commands[name]
                print("  %-*s  %s" % (min_width + 4, name, getattr(c, "description", "")))


def _run(args, allow_unknown_args=False, do_not_parse_args=False, exit_on_failure=True, app_name=None, version=None, config_file=None):
    from requests.exceptions import HTTPError

    '''Executes the Command specified as the first command-line argument.
    
    Attempt to parse the arguments to the command line using the standard Python
    OptionParser.
    
    If allow_unknown_args is True, then pass unrecognized "option" arguments on to the
    command in the "arguments" list.
    
    If do_not_parse_args is True, then the OptionParser will not be applied and all 
    command line options will be passed to the Command execution untouched.  This 
    strongly discouraged!  But, it is useful for deprecated command lines that simply 
    do not fit the OptionParser standard for command line options.  WARNING: caller 
    is responsible even for standard args like -h and --loglevel
    ''' 

    global _application_name
    global _version
    global _config_file
    _application_name = app_name
    _version = version
    _config_file = config_file

    parser = PassThroughOptionParser(usage=(USAGE_TEMPLATE % ("<command>", "")).replace("  ", " "), allow_unknown_args=allow_unknown_args)
    parser.add_option('-v', '--version', dest='version', action="store_true", help="Shows the version for the CLI.")
    parser.add_option('--config', dest='config_file', type="string", help="Specifies the path to a non-default config file to be used for this command.")
    parser.add_option('--loglevel', dest='log_level', type="string", help="Sets the default log level for the CLI.", default='warn')

    try:
        command_name, arguments = _get_command(args)
        show_help = "-h" in arguments or "--help" in arguments
        if command_name == "help":
            command_name, arguments = _get_command(arguments, lookup_command=False)
            show_help = True
        elif command_name:
            subcommand_name, _ = _get_command(arguments, lookup_command=False)
            show_help = show_help or subcommand_name == "help"

        if command_name:
            command = _registered_commands[command_name]        
            # configure the parser for this command, even if just so that we can show help
            command._configure(parser)
        else:
            command = None

        if show_help:
            parser.print_help(append_command_list=(command_name is None))
            sys.exit(1)

        # run this command
        if do_not_parse_args:
            # Allow command lines that simply don't work with OptionsParser
            command.execute({}, args)

        else:
            options, arguments = parser.parse_args(arguments)

            if options.log_level:
                numeric_level = getattr(logging, options.log_level.upper(), None)
                if not isinstance(numeric_level, int):
                    raise ArgumentError("Invalid log level: %s" % options.log_level)
                logging.getLogger().setLevel(numeric_level)
                logger.setLevel(numeric_level)
                logger.info("Set log level to: %s", options.log_level.upper())

            if options.config_file:
                logger.debug("Using cycle config file at: %s", options.config_file)
                _config_file = options.config_file  # global keyword at beginning of function

            if options.version:
                _show_version()

            elif command:
                command.execute(options, arguments)

            else:
                parser.print_help(append_command_list=True)
                sys.exit(1)

    except (ArgumentError, UnknownCommandError) as e:
        if exit_on_failure:
            print_error_msg(e)
            print("")

            # If the error was an unknown command, print the available commands
            append_command_list = isinstance(e, UnknownCommandError)

            parser.print_help(append_command_list=append_command_list)
            sys.exit(1)
        else:
            raise
    except ConfigError as e:
        if exit_on_failure:
            print_error_msg("%s\n     Please check the file or try (re-)initializing." % (e))
            sys.exit(1)
        else:
            raise
    except UserError as e:
        if exit_on_failure:
            print_error_msg(e)
            sys.exit(1)
        else:
            raise
    except HTTPError as e:
        if exit_on_failure:
            print_error_msg("%s\n%s" % (e, e.response.text if e.response.text else ''))
            sys.exit(1)
        else:
            raise
    except Exception as e:
        if exit_on_failure:
            print_error_msg("Unexpected command failure: %s" % e)
            sys.exit(1)
        else:
            raise


def _get_command(args, lookup_command=True):
    original_command_name = None
    command_name = None
    for arg in args:
        arg = arg.strip()
        if not arg.startswith("-") and not arg.startswith("--"):
            command_name = arg
            original_command_name = command_name
            break

    if command_name != "help" and lookup_command:
        
        if command_name and command_name in _deprecated_commands:
            new_name = _deprecated_commands[command_name] 
            logger.warn("%s is deprecated; use %s instead", command_name, new_name)
            command_name = new_name

        if command_name:
            # Check to see if it's a registered command
            if command_name not in _registered_commands:
                alias_found = False
                for new_name, aliases in _command_aliases.items():
                    if command_name in aliases:
                        command_name = new_name
                        alias_found = True

                if not alias_found:
                    # Check for command aliases
                    message = "Unknown command '%s'" % command_name
                    raise UnknownCommandError(message)

    arguments = [x for x in args]
    if command_name:
        arguments.remove(original_command_name)

    return command_name, arguments


def print_error_msg(message):
    print("**** Error: %s" % message, file=sys.stderr)
    _print_stack()


def _print_stack():
    '''Print a stack trace if we're at debug logging'''
    if logger.getEffectiveLevel() == logging.DEBUG:
        traceback.print_exc(file=sys.stderr)


def _show_version():
    global _application_name
    global _version
    print("%s %s" % (_application_name, _version))


if __name__ == "__main__":
    raise Exception("ERROR: Attempt to execute cycle common command line tools directly.")
