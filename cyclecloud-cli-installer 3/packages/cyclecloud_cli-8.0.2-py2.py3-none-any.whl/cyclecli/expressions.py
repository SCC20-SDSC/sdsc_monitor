import re

import six

RESERVED_WORDS = []
# these are standard ClassAd reserved words
RESERVED_WORDS.extend(["error", "false", "is", "isnt", "parent", "true", "undefined"])
# these come because we use a context-free grammar to parse SQL
RESERVED_WORDS.extend(["select", "from", "where", "limit", "update", "delete"])

UNQUOTED_NAME_PATTERN = re.compile("[a-zA-Z_@][a-zA-Z0-9_]*")

QUOTE_CHAR = '"'
APOSTROPHE_CHAR = "'"
ESCAPE_CHAR = "\\"

HEX_SET = "0123456789abcdef"
OCT_SET = "01234567"


def _consists_of(literal, char_set):
    for c in literal.lower():
        if c not in char_set:
            return False
    return True


def attributeIn(attribute, *values):
    if len(values) == 1 and hasattr(values[0], "__iter__"):
        values = values[0]

    list_str = ", ".join([quote(v) for v in values])

    return "%s in {%s}" % (attribute, list_str)


def quoteName(name):
    formatted = name

    if UNQUOTED_NAME_PATTERN.match(name) or name.lower() in RESERVED_WORDS:

        escaped = _escape_string(name, APOSTROPHE_CHAR)
        formatted = APOSTROPHE_CHAR + escaped + APOSTROPHE_CHAR
    
    return formatted


def quote(str):
    return QUOTE_CHAR + _escape_string(str, QUOTE_CHAR) + QUOTE_CHAR


def andAll(expr1, *other_exprs):
    composite = "(%s)" % expr1

    for expr in other_exprs:
        composite = "%s && (%s)" % (composite, expr)

    return composite


def _escape_string(literal, quote_char=QUOTE_CHAR):
    output = ""

    literal = six.ensure_text(literal)

    p = 0
    while p < len(literal):
        c = literal[p]
        p += 1

        code_point = ord(c)

        if c == ESCAPE_CHAR:
            output += ESCAPE_CHAR + ESCAPE_CHAR

        elif c == "\b":
            output += ESCAPE_CHAR + "b"

        elif c == "\f":
            output += ESCAPE_CHAR + "f"

        elif c == "\t":
            output += ESCAPE_CHAR + "t"

        elif c == "\r":
            output += ESCAPE_CHAR + "r"

        elif c == "\n":
            output += ESCAPE_CHAR + "n"

        elif c == quote_char:
            output += ESCAPE_CHAR + quote_char

        elif code_point < 32 or code_point == 127:
            output += ESCAPE_CHAR + format(code_point, "o").zfill(3)

        elif code_point < 127:
            output += c

        elif code_point > 0xFFFF:
            # TODO: handle utf-16 surrogate pairs
            # will only get hit on wide builds of python
            # otherwise the surrogate pairs of utf-16 will be treated as raw code points and decoding errors ensue...
            output += ESCAPE_CHAR + "U" + format(code_point, "x").zfill(8)

        else:
            output += ESCAPE_CHAR + "u" + format(code_point, "x").zfill(4)

    return output


def _unescape_string(literal):

    if '\\' not in literal:
        return str(literal)

    output = ""

    p = 0
    while p < len(literal):
        c = literal[p]
        p += 1

        if c != ESCAPE_CHAR:
            output += str(c)

        else:
            if p >= len(literal):
                raise Exception("Invalid escape sequence!")

            else:
                c = literal[p]

                if c == "b":
                    output += "\b"

                elif c == "f":
                    output += "\f"

                elif c == "t":
                    output += "\t"

                elif c == "r":
                    output += "\r"

                elif c == "n":
                    output += "\n"

                elif c == "u":
                    escaped_sequence = literal[p+1:p+5]
                    if len(escaped_sequence) != 4 or not _consists_of(escaped_sequence, HEX_SET):
                        raise Exception("Invalid escape sequence!")

                    output += (b"\\u%s" % six.ensure_binary(escaped_sequence)).decode("unicode-escape")
                    p += 4

                elif c == "U":
                    escaped_sequence = literal[p+1:p+9].strip()
                    if len(escaped_sequence) != 8 or not _consists_of(escaped_sequence, HEX_SET):
                        raise Exception("Invalid escape sequence!")

                    output += (b"\\U%s" % six.ensure_binary(escaped_sequence)).decode("unicode-escape")
                    p += 8

                elif c not in OCT_SET:
                    output += str(c)

                else:
                    escaped_sequence = literal[p:p+3]
                    if len(escaped_sequence) != 3 or not _consists_of(escaped_sequence, OCT_SET):
                        raise Exception("Invalid escape sequence!")

                    code_point = int(escaped_sequence, 8)
                    output += chr(code_point)
                    p += 2

                p += 1

    return output
