import collections
from json import dumps

from cyclecli import expressions
from six.moves import urllib


# Taken from requests library
class CaseInsensitiveDict(collections.MutableMapping):
    """
    A case-insensitive ``dict``-like object.

    Implements all methods and operations of
    ``collections.MutableMapping`` as well as dict's ``copy``. Also
    provides ``lower_items``.

    All keys are expected to be strings. The structure remembers the
    case of the last key to be set, and ``iter(instance)``,
    ``keys()``, ``items()``, ``iterkeys()``, and ``iteritems()``
    will contain case-sensitive keys. However, querying and contains
    testing is case insensitive:

        cid = CaseInsensitiveDict()
        cid['Accept'] = 'application/json'
        cid['aCCEPT'] == 'application/json'  # True
        list(cid) == ['Accept']  # True

    For example, ``headers['content-encoding']`` will return the
    value of a ``'Content-Encoding'`` response header, regardless
    of how the header name was originally stored.

    If the constructor, ``.update``, or equality comparison
    operations are given keys that have equal ``.lower()``s, the
    behavior is undefined.

    """
    def __init__(self, data=None, **kwargs):
        self._store = dict()
        if data is None:
            data = {}
        self.update(data, **kwargs)

    def __setitem__(self, key, value):
        # Use the lowercased key for lookups, but store the actual
        # key alongside the value.

        if type(value) is dict and type(value) is not CaseInsensitiveDict:
            value = CaseInsensitiveDict(value)

        self._store[key.lower()] = (key, value)

    def __getitem__(self, key):
        value = self._store.get(key.lower())
        if value:
            return value[1]
        else:
            return None

    def __delitem__(self, key):
        del self._store[key.lower()]

    def __iter__(self):
        return (casedkey for casedkey, mappedvalue in list(self._store.values()))

    def __len__(self):
        return len(self._store)

    def lower_items(self):
        """Like iteritems(), but with all lowercase keys."""
        return (
            (lowerkey, keyval[1])
            for (lowerkey, keyval)
            in list(self._store.items())
        )

    def __eq__(self, other):
        if isinstance(other, collections.Mapping):
            other = CaseInsensitiveDict(other)
        else:
            return NotImplemented
        # Compare insensitively
        return dict(self.lower_items()) == dict(other.lower_items())

    # Copy is required
    def copy(self):
         return CaseInsensitiveDict(list(self._store.values()))

    def __repr__(self):
        return '%s(%r)' % (self.__class__.__name__, dict(list(self.items())))

    def get_dict(self):
        d = dict(self)
        for k, v in d.items():
            if type(v) is CaseInsensitiveDict:
                d[k] = v.get_dict()
        return d


class RestDatastore(object):

    def __init__(self, rooturl, session):

        self._rooturl = rooturl

        self._session = session

    def _convert_to_records(self, dictionaries):
        records = [CaseInsensitiveDict(d) for d in dictionaries]

        return records

    def _convert_from_records(self, records):
        if type(records) is list:
            dictionaries = [r.get_dict() if type(r) is CaseInsensitiveDict else r for r in records]
        else:
            dictionaries = records.get_dict() if type(records) is CaseInsensitiveDict else records

        return dictionaries

    def _get_policy_params(self, policy):
        params = ""

        if policy:
            for key, val in policy.items():
                params += "&policy_%s=%s" % (key, val)

        return params

    def find(self, for_type, filter_expr=None):
        view = {"AdType":"View"}

        view["ForType"] = for_type

        if filter_expr:
            view["Filter"] = {"$expr": filter_expr}

        view = dumps(view)

        response = self._session.post("%s/exec/view?input_format=json&format=json" % self._rooturl, data=view)
        response.raise_for_status()

        return self._convert_to_records(response.json())

    def delete(self, for_type, filter_expr, policy=None):
        composite_expr = 'AdType === "%s"' % for_type

        composite_expr = expressions.andAll(composite_expr, filter_expr)

        composite_expr = urllib.quote(composite_expr)

        policy_params = self._get_policy_params(policy)

        response = self._session.post("%s/db?input_format=json&policyexpr_SynchronizeFilter=%s%s" % (self._rooturl, composite_expr, policy_params), data="[]")
        response.raise_for_status()

        return []

    def save(self, records):
        if not isinstance(records, str):
            records = self._convert_from_records(records)
            records = dumps(records)

        response = self._session.post("%s/db?input_format=json&format=json&policy_ReturnStoredAds=true&policy_CombineAttributes=true" % self._rooturl, data=records)
        response.raise_for_status()

        return self._convert_to_records(response.json())
