from cyclecli.datastore import CaseInsensitiveDict

def create(type_name=None):
    record = CaseInsensitiveDict()

    if type_name:
        record["AdType"] = type_name

    return record
