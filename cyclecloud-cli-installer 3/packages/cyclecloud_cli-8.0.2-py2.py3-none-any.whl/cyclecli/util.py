from __future__ import division

import binascii
import hashlib
import hmac
import io
import platform
import string
import sys
from array import array
from time import time

import cyclecli

for typecode in 'IL':
    if len(array(typecode, [0]).tostring()) == 4:
        uint32 = typecode
        break
    else:
        raise RuntimeError("Neither 'I' nor 'L' are unsigned 32-bit integers.")


def make_missing_parent_dir(filepath):
    """Creates the parent directory of filepath if it does not already exist"""
    parent = os.path.dirname(os.path.abspath(filepath))
    if not os.path.exists(parent):
        os.makedirs(parent)


def write_config_to_file(filepath, config):
    """Write ConfigParser config to FILEPATH"""
    with open(filepath, 'wb') as f:
        config.write(f)


def is_windows():
    return 'windows' in platform.system().lower()


def convert_config_parser_to_str(config_parser):
    if sys.version_info[0] < 3:
        buf = io.BytesIO()
    else:
        buf = io.StringIO()
    config_parser.write(buf)
    return buf.getvalue()


def make_only_one_arg_function(application_name):
    """
    Creates a function that raises an error if more than one argument is present.
    Uses a preformatted string for the error message
    """
    message_template = "%s config ${command} <config_name> requires one and only one argument" \
                       % application_name
 
    def allow_only_one_arg(args, command):
        error_message = string.Template(message_template).substitute({"command": command})
        if len(args) > 1 or len(args) < 1:
            raise cyclecli.UserError(error_message)

    return allow_only_one_arg


class CryptError(Exception): pass
def _hash(s):
    md = hashlib.sha1()
    md.update(s)
    return md.digest()

_ivlen = 16
_maclen = 8
_state = _hash(repr(time()).encode("utf8"))

try:
    import os
    _pid = repr(os.getpid()).encode("utf8")
except ImportError as AttributeError:
    _pid = b''

def encode(text):
    return binascii.hexlify(p3_encrypt(text, b"09087a22d7e26f97")).decode("utf8")

def decode(text):
    try:
        return p3_decrypt(binascii.unhexlify(text), b"09087a22d7e26f97")
    except CryptError:
        raise ValueError("Invalid key")

def _expand_key(key, clen):
    blocks = (clen+19) // 20
    xkey=[]
    seed=key
    for i in range(blocks):
        seed=_hash(key+seed)
        xkey.append(seed)
    j = b"".join(xkey)
    return array (uint32, j)

def p3_encrypt(plain,key):
    global _state
    H = _hash

    # change _state BEFORE using it to compute nonce, in case there's
    # a thread switch between computing the nonce and folding it into
    # the state.  This way if two threads compute a nonce from the
    # same data, they won't both get the same nonce.  (There's still
    # a small danger of a duplicate nonce--see below).
    _state = b'X'+_state

    # Attempt to make nlist unique for each call, so we can get a
    # unique nonce.  It might be good to include a process ID or
    # something, but I don't know if that's portable between OS's.
    # Since is based partly on both the key and plaintext, in the
    # worst case (encrypting the same plaintext with the same key in
    # two separate Python instances at the same time), you might get
    # identical ciphertexts for the identical plaintexts, which would
    # be a security failure in some applications.  Be careful.
    plain = plain.encode("utf8")
    nlist = [repr(time()).encode("utf8"), _pid, _state, repr(len(plain)).encode("utf8"), plain, key]
    nonce = H(b",".join(nlist))[:_ivlen]
    _state = H(b'update2'+_state+nonce)
    k_enc, k_auth = H(b'enc'+key+nonce), H(b'auth'+key+nonce)
    n=len(plain)                        # cipher size not counting IV

    stream = array(uint32, plain+b'0000'[n&3:]) # pad to fill 32-bit words
    xkey = _expand_key(k_enc, n+4)
    for i in range(len(stream)):
        stream[i] = stream[i] ^ xkey[i]
    ct = nonce + stream.tostring()[:n]
    auth = _hmac(ct, k_auth)
    return ct + auth[:_maclen]

def p3_decrypt(cipher,key):
    H = _hash
    n=len(cipher)-_ivlen-_maclen        # length of ciphertext
    if n < 0:
        raise CryptError("invalid ciphertext")
    nonce,stream,auth = \
      cipher[:_ivlen], cipher[_ivlen:-_maclen]+b'0000'[n&3:],cipher[-_maclen:]
    k_enc, k_auth = H(b'enc'+key+nonce), H(b'auth'+key+nonce)
    vauth = _hmac(cipher[:-_maclen], k_auth)[:_maclen]
    if auth != vauth:
        raise CryptError("invalid key or ciphertext")

    stream = array(uint32, stream)
    xkey = _expand_key (k_enc, n+4)
    for i in range (len(stream)):
        stream[i] = stream[i] ^ xkey[i]
    plain = stream.tostring()[:n]
    return plain


def _hmac(msg, key):
    h = hmac.new(key, msg, digestmod=hashlib.sha1)
    return h.digest()
