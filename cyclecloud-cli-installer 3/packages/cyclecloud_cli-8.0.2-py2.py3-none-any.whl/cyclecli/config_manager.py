import os
import shutil
import logging
import cyclecli
from cyclecli import util

from six.moves import configparser

logger = logging.getLogger(__name__)


DESCRIPTION = """
    This module manages named configurations

    It keeps track of which configuration file is currently in use by means of
    a "reverse-link." This "reverse link" is simply an empty file w/ the suffix `.current`.
    This class provides a consistent means to manage multiple configurations across
    Windows and Linux. While Windows technically supports symlinks, they can only be created
    by administrators.

    This class uses "reverse-links" which are the normal configuration files
    with an optional header that indicates whether the given configuration is
    the current one in use. If this header is present in a given configuration
    file, it indicates that the current configuration file is in use, the path
    (link) to the real configuration file.

    For example:

    ~/.cycle/config.ini   -- the real config file

    ~/.cycle/configurations/
                        default.current   -- the .current suffix indicates that the configuration
                                             named 'default' is currently in use_instance_creds
                                             this file is empty
                        prod              -- another configuration, not currently in use
                                             this file is not empty 
                        dev               -- another configuration, not currently in use
                                             this file is not empty 

    """


class InvalidNumberOfCurrentLinksError(Exception):
    pass


def touchfile(filename):
    with open(filename, 'a') as f:
        f.write('')


def truncate(filename):
    with open(filename, 'w') as f:
        f.write('')


def validate_config_name(name):
    if '.current' not in name:
        return True

    suffix = name.split('.')[-1]
    if suffix.lower() == 'current':
        raise cyclecli.UserError("Configurations cannot have the suffix .current")
    

def convert_to_rlink(name, application_dir, target_config):
    """Convert the configuration NAME to a reverse link"""
    rlink = RLink(name, application_dir, target_config)
    shutil.copy(rlink.original, target_config)
    truncate(rlink.link_path)
    logger.debug("deleting original source file at %s" % rlink.original)
    os.remove(rlink.original)
    return rlink


def undo_rlink(rlink):
    """
    Reverts an rlink to a normal configuration file
    """

    # sometimes ~/.cycle/config.ini does not exist as the user might have deleted it
    if os.path.exists(rlink.target_config):
        shutil.copyfile(rlink.target_config, rlink.original)

    os.remove(rlink.link_path)
    logger.debug("Undid rlink at %s. Restored original %s"
                 % (rlink.link_path, rlink.original))


def delete_config(props, name):
    """Delete configuration NAME"""
    coll = make_config_collection(props)
    if name == coll.current.name:
        raise cyclecli.UserError("Cannot delete the configuration \"%s\" as it is currently in use"
                                 % name)
    config_path = os.path.join(props.application_dir, name)
    if name not in list(coll.list.keys()):
        logger.error("No configuration named %s exists, nothing to do" % name)
    else:
        os.remove(config_path)


def raise_if_already_in_use(props, name, config_collection):
    assert isinstance(config_collection, ConfigCollection)
    """Raise an error if the given configuration is already in use"""
    current_config_name = _get_current_config_name(config_collection)

    if current_config_name == name:
        raise cyclecli.UserError("Configuration %s is already in use" % name)


def rename(props, old_name, new_name):
    """
    Rename an existing configuration
    """
    coll = make_config_collection(props)
    current_name = _get_current_config_name(coll)
    if current_name == old_name:
        current_link_path = coll.current.link_path
        new_link_path = os.path.join(props.application_dir, "%s.current" % new_name)
        shutil.move(current_link_path, new_link_path)
        return

    old_config_path = os.path.join(props.application_dir, old_name)
    new_config_path = os.path.join(props.application_dir, new_name)
    if not os.path.exists(old_config_path):
        raise cyclecli.UserError("No configuration with the name %s exists, nothing to do"
                                 % old_name)

    shutil.move(old_config_path, new_config_path)


def show(props):
    """
    Display current configuration
    """
    coll = make_config_collection(props)
    if coll.current is None:
        raise cyclecli.UserError("No configuration currently in use for %s" % props.application_name)
    current_config = coll.list[coll.current.name]
    identifier, value = current_config["identifier"].popitem()
    print(('%s : %s = %s' % (coll.current.name, identifier, value)))


def update(props, name):
    """
    Updates a configuration in place.
    This function should only be called if the named configuration already
    is the current configuration.
    Unlike the `use` function, we do not undo a reverse link
    """
    new_config_path = os.path.join(props.application_dir, name)
    target_config = props.target_config

    shutil.copyfile(new_config_path, target_config)
    rlink = convert_to_rlink(name, props.application_dir, target_config)
    return rlink


def use(props, name):
    """
    use configuration NAME for the current configuration.
    If current_rlink exists, undo it
    """
    logger.debug("Making %s the current configuration" % name)
    target_config = props.target_config
    new_config_path = os.path.join(props.application_dir, name)
    coll = make_config_collection(props)

    try:
        raise_if_already_in_use(props, name, coll)
    except cyclecli.UserError:
        logger.debug("Configuration %s is already in use.", name)
        return RLink(name, props.application_dir, target_config)

    if not os.path.exists(new_config_path):
        raise cyclecli.UserError("Configuration %s has not yet been created. Please create it "
                                 "first with the command `%s config create %s`"
                                 % (name, props.application_name.lower(), name))

    if coll.current is not None:
        undo_rlink(coll.current)

    rlink = convert_to_rlink(name, props.application_dir, target_config)

    return rlink


def make_config(props, name=None, content=None):
    """Make a configuration NAME with CONTENT"""
    assert content is not None, "Content for configuration must not be None"
    assert name is not None, "Name for configuration must not be None"
    new_config_path = os.path.join(props.application_dir, name)
    if not os.path.exists(props.application_dir):
        os.makedirs(props.application_dir)
    with open(new_config_path, 'w') as f:
        f.write(content)
    logger.debug("Created new configuration %s at %s" % (name, new_config_path))
    return new_config_path


def _parse_config_file_identifier(config_filename, identifier):
    """Parse the cycleserver url from CONFIG_FILENAME"""
    parser = configparser.RawConfigParser()
    parser.read(config_filename)
    if not parser.has_option("cycleserver", identifier):
        return None
    return parser.get("cycleserver", identifier)


def _get_current_config_name(config_collection):
    """
    Gets the name of the current configuration, if it is None.
    Otherwise returns None
    """
    assert isinstance(config_collection, ConfigCollection)
    if config_collection.current is not None:
        return config_collection.current.name
    return config_collection.current


def _check_for_multiple_current_links(config_list):
    """
    This is an internal sanity check.
    There cannot be more than 1 .current file for a given application
    at any given time
    """
    current_files = [f for f in config_list if f.endswith(".current")]
    if len(config_list) < 1:
        return

    basedir = os.path.dirname(config_list[0])
    if len(current_files) > 1:
        raise InvalidNumberOfCurrentLinksError(
            "There can be at most 1 '*.current' files at a given time in %s."
            " You have %d." % (basedir, len(current_files)))


def _make_config_item(config_filepath, target_config):
    is_current = False
    item = {}
    config_filename = os.path.basename(config_filepath)
    if config_filename.endswith(".current"):
        config_name = config_filename.split(".current")[0]
        value = _parse_config_file_identifier(target_config, "url")
        is_current = True
    else:
        config_name = config_filename
        value = _parse_config_file_identifier(config_filepath, "url")
    item["current"] = is_current

    item["identifier"] = {"url": value}
    return config_name, item


def _make_config_list(config_list, target_config):
    """
    parses list of configurations into a usable dictionary
    config_list - array of absolute filepaths for named configurations
    """
    current = None
    config_list_dict = {}
    _check_for_multiple_current_links(config_list)
    for config_filepath in config_list:
        config_name, item = _make_config_item(config_filepath, target_config)
        config_list_dict[config_name] = item
        if config_filepath.endswith('.current'):
            current = config_name

    return config_list_dict, current


def upgrade_legacy_configurations(props):
    _, _, config_files = next(os.walk(props.legacy_application_dir))
    if len(config_files) < 1:
        return

    logger.info("Found %s configuration files in legacy directory %s. Migrating them to %s"
                % (", ".join(config_files), props.legacy_application_dir, props.application_dir))
    
    for f in config_files:
        shutil.move(os.path.join(props.legacy_application_dir, f),
                    os.path.join(props.application_dir, f))

    shutil.rmtree(props.legacy_application_dir)
    

def make_config_collection(props):
    """
    Makes a ConfigCollection instance
    configurations are stored in ~/.cycle/configurations
    they were previously stored in ~/.cycle/<application_name>
    This method migrates configurations in ~/.cycle/<application_name> to ~/.cycle/configurations
    if any are found
    """
    if not os.path.exists(props.application_dir):
        os.makedirs(props.application_dir)
                    
    if os.path.exists(props.legacy_application_dir):
        upgrade_legacy_configurations(props)

    config_list_names = os.listdir(os.path.join(props.application_dir))
    if len(config_list_names) < 1 and os.path.exists(props.target_config):
        touchfile(os.path.join(props.application_dir, 'default.current'))
        config_list_names = ['default.current']
    
    config_list = [os.path.join(props.application_dir, n) for n in config_list_names]
    current = None
    config_list_dict, current = _make_config_list(config_list, props.target_config)
    
    if current:
        current_rlink = RLink(current, props.application_dir, props.target_config)
    else:
        current_rlink = None
    coll = ConfigCollection(props, config_list_dict, current=current_rlink)
    return coll


def make_and_use_config(props, name, content):
    """
    Create a new configuration and make it the current configuration.
    Unlink the current configuration if it exists.
    """
    make_config(props, name=name, content=content)

    coll = make_config_collection(props)
    current_name = _get_current_config_name(coll)

    # if the current configuration in use has the same name as the new one
    # we want to update it in place
    if current_name != name:
        rlink = use(props, name)
    else:
        logger.warn("The configuration \"%s\" already exists. Overwriting it in place." % name)
        rlink = update(props, name)
    return rlink


def list_configurations(props):
    coll = make_config_collection(props)
    if len(coll.list) == 0:
        raise cyclecli.UserError('You haven\'t created any named configurations yet.'
                                 ' Get started with `%s config create <new_name>'
                                 ' or %s initialize'
                                 % (props.application_name, props.application_name))

    print('Available Configurations:')
    for k, v in coll.list.items():
        identifier, value = coll.list[k]["identifier"].popitem()
        current_marker = ""
        if v["current"]:
            current_marker = ' [CURRENT] '
        print(('%s : %s = %s %s' % (k, identifier, value, current_marker)))


def get_current_config_name(config_file, application_name):
    cycle_homedir = os.path.expanduser("~/.cycle")
    config_props = ConfigProperties(cycle_homedir, config_file,
                                                   application_name.lower())
    
    coll = make_config_collection(config_props)
    return _get_current_config_name(coll)

    
class RLink(object):
    """
    Create a Reverse Link data structure
    """
    def __init__(self, name, application_dir, target_config):
        self.name = name
        self.application_dir = application_dir
        self.original = os.path.join(application_dir, name)
        self.link_path = os.path.join(application_dir, "%s.current" % name)
        self.target_config = target_config


class ConfigProperties(object):
    """
    Properties common to all named configurations for a given application_name
    """
    def __init__(self, basedir, target_config, application_name):
        self.basedir = basedir
        self.target_config = os.path.join(basedir, target_config)
        self.application_name = application_name
        self.legacy_application_dir = os.path.join(basedir, application_name)
        self.application_dir = os.path.join(basedir, 'configurations')


class ConfigCollection(object):
    """
    This is just a value class with no methods
    """
    def __init__(self, config_properties, config_list, current=None):
        self.props = config_properties
        self.list = config_list
        self.current = current
