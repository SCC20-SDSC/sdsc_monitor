__version__ = "8.0.2-SNAPSHOT"
__release_version__ = __version__.replace("-SNAPSHOT", "")
