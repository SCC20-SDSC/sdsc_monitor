import logging
from collections import OrderedDict

import six
from six.moves import configparser

logger = logging.getLogger(__name__)


class CaseInsensitiveList(list):
    def __contains__(self, string):
        return string.lower() in (n.lower() for n in self)


TRUES = CaseInsensitiveList(['true', 't', 'yes', 'y'])
FALSES = CaseInsensitiveList(['false', 'f', 'no', 'n'])
BOOLEANS = CaseInsensitiveList(TRUES).extend(FALSES)


class ConfigDict(object):
    '''A dictionary-like object which helps read/write certain values to an ini file.'''

    # start vanilla pass through functions
    def __init__(self, **kwargs):
        self._delegate = OrderedDict()
        self.update(**kwargs)

    def __contains__(self, key):
        return key in self._delegate

    def __delitem__(self, key):
        del self._delegate[key]

    def __eq__(self, other):
        if not isinstance(other, ConfigDict):
            return False

        return self._delegate == other._delegate

    def __getitem__(self, key):
        return self._delegate[key]

    def __iter__(self):
        for i in self._delegate:
            yield i

    def __len__(self):
        return len(self._delegate)

    def __setitem__(self, key, value):
        if not isinstance(key, six.string_types):
            raise KeyError("Keys must be strings!")
        if not isinstance(value, six.string_types) and not isinstance(value, ConfigDict):
            raise ValueError("Values must be strings or 'ConfigDict'!")
        self._delegate[key] = value

    def __repr__(self):
        return repr(self._delegate)

    def __str__(self):
        return str(self._delegate)

    def get(self, key, default=None):
        if key in self:
            return self.__getitem__(key)
        else:
            return default

    def items(self):
        for i in self._delegate.items():
            yield i

    def keys(self):
        for k in list(self._delegate.keys()):
            yield k

    def update(self, **kwargs):
        for k, v in kwargs.items():
            self.__setitem__(k, v)

    def values(self):
        for v in list(self._delegate.values()):
            yield v
    # end vanilla pass through functions

    def get_list(self, key, default=None):
        raw_value = self.get(key)
        if raw_value is not None:
            return [i.strip() for i in raw_value.split(",")]
        else:
            return default

    def set_list(self, key, value):
        if isinstance(value, (str,)):
            self[key] = value
        else:
            self[key] = ", ".join([str(v) for v in value])

    def get_boolean(self, key, default=None):
        raw_value = self.get(key)
        if raw_value is not None:
            if isinstance(raw_value, bool):
                return raw_value
            else:
                return raw_value in TRUES
        else:
            return default

    def set_boolean(self, key, value):
        if isinstance(value, (str,)):
            self[key] = value
        elif value:
            self[key] = "true"
        else:
            self[key] = "false"

    def get_sections(self, section_type):
        if " " in section_type:
            raise Exception("Arg 'section_type' cannot contain a space!")

        sections_by_name = {}
        for k in list(self.keys()):
            if k.startswith(section_type + " ") or k == section_type:
                name = k[len(section_type) + 1:]
                if name in sections_by_name:
                    logger.warn("Section '%s' appears twice in configuration!", name)
                sections_by_name[name] = self[k]

        return sections_by_name

    def ensure_section(self, key):
        if key not in self:
            self[key] = ConfigDict()
        if not isinstance(self[key], ConfigDict):
            raise ValueError("Value for '%s' is not a ConfigDict!" % key)


def read_config(config_file_path):
    '''Read the specified ini file in as a ConfigDict.'''
    p = configparser.RawConfigParser()
    p.read(config_file_path)

    config_dict = ConfigDict()

    for section_name in p.sections():
        section = ConfigDict()
        config_dict[section_name] = section
        for option_name in p.options(section_name):
            section[option_name] = p.get(section_name, option_name)

    return config_dict


def write_config(config_file_path, config_dict):
    '''Write the given dictionary (preferably a ConfigDict) to the specified ini path.'''
    p = configparser.RawConfigParser()

    for section_name in list(config_dict.keys()):
        p.add_section(section_name)
        for option_name, option_value in config_dict[section_name].items():
            p.set(section_name, option_name, option_value)

    with open(config_file_path, "w") as f:
        p.write(f)
