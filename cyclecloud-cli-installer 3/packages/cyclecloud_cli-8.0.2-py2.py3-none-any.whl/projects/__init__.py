import fnmatch
import glob
import hashlib
import io
import json
import logging
import os
import platform
import re
import shutil
import subprocess
import tarfile
import zipfile
from collections import namedtuple

import projects.config
from six.moves import urllib

logger = logging.getLogger(__name__)

_CHUNK_SIZE = 8192
__IS_JYTHON__ = platform.system().lower() == "java"

# NOTE: this is needed to prevent spinning up multiple pogo thread pools while
# inside cycle server (we use dataman's version of pogo as the official version
# for now - someday pogo might move to the platform directly, who knows)
if __IS_JYTHON__:
    from dataman import pogoapi as pogo


_azcopy_path = None
def _get_azcopy_path():
    global _azcopy_path
    if not _azcopy_path:
        possible_venv_path = os.path.dirname(__file__)
        while True:
            possible_azcopy_path = os.path.join(possible_venv_path, "bin", "azcopy")
            if os.path.exists(possible_azcopy_path):
                _azcopy_path = possible_azcopy_path
                break
            possible_azcopy_path = os.path.join(possible_venv_path, "Scripts", "azcopy.exe")
            if os.path.exists(possible_azcopy_path):
                _azcopy_path = possible_azcopy_path
                break
            possible_venv_path_parent = os.path.dirname(possible_venv_path)
            if possible_venv_path_parent == possible_venv_path:
                break
            possible_venv_path = possible_venv_path_parent
        if not _azcopy_path:
            _azcopy_path = shutil.which("azcopy")
    return _azcopy_path


class ProjectAmbiguousDefault(Exception):
    pass


class ProjectClusterNotFound(Exception):
    pass

class ProjectFetchException(Exception):
    pass


def calc_md5(path):
    m = hashlib.md5()

    with open(path, "rb") as f:
        buf = f.read(8192)
        while buf:
            m.update(buf)
            buf = f.read(8192)

    return m.hexdigest().lower()


def get_specs_uploadable_dirs(specs_dir):
    '''
    Find subdirectories of all specs in specs_dir 'project/specs' but exclude the chef subdirectory
    Returns a tuple of absolute local directory path and the remote subdirectory
    '''
    upload_dirs = []
    if not os.path.exists(specs_dir):
        return upload_dirs

    _, spec_names, _ = next(os.walk(specs_dir))
    specs = [os.path.join(specs_dir, n) for n in spec_names]

    for d in specs:
        _, subdirs, _ = next(os.walk(d))
        # if the directory has no subdirectories, don't include it
        if len(subdirs) == 0:
            continue
        else:
            # remove chef!
            if 'chef' in subdirs:
                subdirs.remove('chef')
            for subdir in subdirs:
                subdir_tuple = (os.path.join(d, subdir), '%s/%s' % (os.path.basename(d), subdir))
                upload_dirs.append(subdir_tuple)

    return upload_dirs


def assert_and_resolve_template_path_exists(template):
    template_path = os.path.expanduser(template)
    if not os.path.exists(template_path):
        raise ProjectClusterNotFound("No cluster template found at path %s" % template)

    return template_path


ClusterDefinition = namedtuple('ClusterDefinition', ['name', 'template'])


def get_current_project(version=None):
    '''Return a Project for the cwd or raise an exception if there is no such project.'''
    path = os.getcwd()
    proj = get_project(path, version=version)
    if proj is None:
        raise Exception("No project at specified path: %s" % path)
    return proj


def set_default_lockers(lockers):
    '''Set the global default locker setting in the [CycleCloud] section of your ini.'''
    if __IS_JYTHON__:
        raise Exception("Cannot set default locker from within Jython")

    import cyclecli
    config_file = cyclecli.find_config_file()
    config_dict = projects.config.read_config(config_file)

    config_dict.ensure_section("cyclecloud")
    if lockers:
        config_dict["cyclecloud"].set_list("default_project_locker", lockers)
    else:
        del config_dict["cyclecloud"]["default_project_locker"]

    projects.config.write_config(config_file, config_dict)


def initialize(name, version=None, path=None):
    '''Create a new project skeleton in the cwd or provided path.'''
    return Project.initialize(name, version=version, path=path)


def get_project(path, version=None):
    project_root = os.path.abspath(os.path.expanduser(path)).rstrip(os.sep)

    while True:
        if Project.is_project(project_root):
            return Project(project_root, version=version)

        next_root = os.path.dirname(project_root)
        if next_root != project_root:
            project_root = next_root
        else:
            return None

def fetch_project(url, path):
    Project.fetch(url, path)


def _extract_project_zip_url(url, path):
    try:
        res = urllib.request.urlopen(url)
    except urllib.error.HTTPError as e:
        if e.code == 403:
            if e.info().getheader('X-RateLimit-Remaining') == '0':
                raise ProjectFetchException("GitHub hourly rate limit exceeded")
        raise ProjectFetchException("Unable to fetch project: %s" % str(e))

    if res.code == 200:
        data = io.BytesIO(res.read())
        archive = zipfile.ZipFile(data)
        # Note: Github archives are stored with the project name as the top level directory
        # so we strip this off when extracting (it will be the first item in namelist)
        # Example: getting "github.com/cyclecloud/test-project/archive/master.zip" will yield a archive
        # with a top directory named `test-project-master` which we want to ignore.
        tld = archive.namelist()[0]
        for member in archive.infolist():
            member.filename = member.filename[len(tld):]
            if member.filename != "":
                archive.extract(member, path)
    else:
        raise Exception("Unable to download archive at %s" % url)


class Project(object):
    '''
    Class to manage a CycleCloud project on disk.

    NOTE: It is not intended for this class to directly provide interaction to the user
    but rather to be a utility to the real CLI logic which should be housed elsewhere.
    '''

    @staticmethod
    def is_project(path):
        project_root = os.path.abspath(path)
        project_settings = os.path.join(project_root, "project.ini")

        if os.path.exists(project_settings):
            try:
                config = projects.config.read_config(project_settings)
            except:
                config = None

            if config and "project" in config and config["project"].get("name"):
                return True

        return False

    @staticmethod
    def initialize(name, version=None, path=None):
        if path is None:
            path = os.getcwd()

        project_root = os.path.abspath(path)
        if get_project(project_root) is not None:
            raise Exception("Specified path is already a project or part of a project: %s" % path)

        project_dir = os.path.join(project_root, ".project")
        project_settings = os.path.join(project_root, "project.ini")

        if os.path.exists(project_dir) or os.path.exists(project_settings):
            raise Exception("Specified path appears to be a partial or damaged project: %s" % path)

        os.makedirs(project_dir)

        config = {"project": {"name": name, "type": "application"}}
        if version is not None:
            config["project"]["version"] = version
        projects.config.write_config(project_settings, config)

        skel = [("templates", ),
                ("specs", ),
                ("blobs", )]

        for s in skel:
            path = os.path.join(project_root, *s)
            if not os.path.exists(path):
                os.makedirs(path)

        # Create the project and add a default spec the same name as the project
        project = Project(project_root)
        project.add_spec("default")
        return project

    @staticmethod
    def fetch(url, path):
        """ Given a 'url' to a project will fetch the contents to the local filesystem at 'path' 

        Currently supports downloading from GitHub:
          https://github.com/ACCOUNT/PROJECT   
             => looks for latest release (github.com/account/project/releases/latest)
               => If no releases, just download master (https://github.com/ACCOUNT/NAME/archive/master.zip)
          https://github.com/ACCOUNT/PROJECT/releases/VERSION
             => Is this a real release, look for json at https://api.github.com/repos/ACCOUNT/PROJECT/releases/tags/VERSION
                => YES - read json and download assets + source
                => NO - just download the archive (https://github.com/ACCOUNT/PROJECT/archive/VERSION.zip)

        Future URLS to be supported!
           az://account/container/projects/myproject/1.0.0 (coming soon)
           s3://bucket/projects/myproject/1.0.0 (coming soon)
           gz://bucket/projects/myproject/1.0.0 (coming soon)
           file:///path/to/project/1.0.0 (coming soon)
        """

        path = os.path.realpath(os.path.expanduser(path))
        if not os.path.isdir(path):
            os.makedirs(path)

        # Check to see if it's a github url
        r = re.compile(r"^https?://+(www\.)?github\.com", re.I)
        if r.match(url):
            Project._fetch_github(url, path)
        else:
            raise ProjectFetchException("Invalid URL: Only Github URLs are currently supported")

    @staticmethod
    def _fetch_github(url, path):
        # Regex which will pull out account, repo and release names
        r = re.compile(r"^https?://+(www\.)?github\.com/+(?P<account>[^/]+)/+(?P<repo>[^/]+)(/+releases/+(?P<release>[^/]+)?)?$", re.IGNORECASE)

        if not os.path.isdir(path):
            os.makedirs(path)

        match = r.match(url.strip("/"))
        if match is None:
            raise ProjectFetchException("Invalid GitHub URL: Expected https://github.com/ACCOUNT/REPO or https://github.com/ACCOUNT/REPO/releases/RELEASE")

        github_account = match.group("account")
        github_project = match.group("repo")
        github_tag = match.group("release")

        if github_tag is None:
            release_url = "https://api.github.com/repos/%s/%s/releases/latest" % (urllib.parse.quote(github_account), urllib.parse.quote(github_project))
        else:
            release_url = "https://api.github.com/repos/%s/%s/releases/tags/%s" % (urllib.parse.quote(github_account), urllib.parse.quote(github_project), urllib.parse.quote(github_tag))


        # Check to see if the release URL is valid
        # i.e. query the `release_url`, if 404 there is no release
        # if 200, parse the JSON!
        release = False
        try:
            res = urllib.request.urlopen(release_url)
            if res.code == 200:
                data = res.read()
                release = True
        except urllib.error.HTTPError as e:
            if e.code == 404:
                release = False
            elif e.code == 403:
                if e.info().getheader('X-RateLimit-Remaining') == '0':
                    raise ProjectFetchException("GitHub hourly rate limit exceeded")
            else:
                raise ProjectFetchException("Unable to read project release information: %s" % str(e))

        if release:
            release = json.loads(data)
            _extract_project_zip_url(release['zipball_url'], path)
            blobs_dir = os.path.join(path, 'blobs')
            assets = release.get('assets', [])
            if assets and not os.path.isdir(blobs_dir):
                os.makedirs(blobs_dir)

            for asset in assets:
                Project._download_asset(asset, blobs_dir)
        else: 
            # There is no release, use the tag if specified otherwise default to 'master' which will just pull the
            # top of the master branch
            if github_tag is None:
                tag = "master"
            else:
                # Will this ever happen?
                tag = github_tag

            archive_url = "https://github.com/%s/%s/archive/%s.zip" % (urllib.parse.quote(github_account), urllib.parse.quote(github_project), urllib.parse.quote(tag))
            _extract_project_zip_url(archive_url, path)

    @staticmethod
    def _download_asset(asset, blobs_dir):
        try:
            res = urllib.request.urlopen(asset['browser_download_url'])
            if res.code == 200:
                with open(os.path.join(blobs_dir, asset['name']), 'wb') as f:
                    while True:
                        data = res.read(_CHUNK_SIZE)
                        if not data:
                            break
                        f.write(data)
        except urllib.error.HTTPError as e:
            if e.code == 403 and e.info().getheader('X-RateLimit-Remaining') == '0':
                raise ProjectFetchException("GitHub hourly rate limit exceeded")
            else:
                raise ProjectFetchException("Unable to download asset: %s" % str(e))

    def __init__(self, path, version=None):
        self._project_root = os.path.abspath(path)

        self._version = version

        if not Project.is_project(self._project_root):
            raise Exception("No project at specified path: %s" % self._project_root)

        project_settings = os.path.join(self._project_root, "project.ini")

        self._project_settings = projects.config.read_config(project_settings)

        # Special case: support setting the version from a cli option --project-version
        # This is so that build systems can set custom versions
        if self._version is not None:
            self._project_settings.get("project", {})['version'] = version

    def _generate_manifest(self):
        """ Creates a manifest.json file based on the project.ini
         """
        manifest = {}

        # Copy the whole project section into the manifest
        for key, value in self._project_settings['project'].items():
            manifest[key] = value

        # Process all blobs
        manifest['blobs'] = []

        for section in self._project_settings.get_sections('blobs').values():
            for pattern in section.get_list("files"):
                matches_by_name = {}

                matches = glob.glob(os.path.join(self._project_root, "blobs", pattern))
                for match in matches:
                    relative_path = os.path.relpath(match, os.path.join(self._project_root, "blobs"))
                    md5 = calc_md5(match)
                    matches_by_name[relative_path] = {'path': relative_path, 'checksum': md5}

                if not matches_by_name:
                    # Raise some kind of exception for blob not found
                    raise Exception("Unable to find blob '%s', please make sure this file exists and try again." % pattern)

                # Add our matches to the set                
                manifest['blobs'] += list(matches_by_name.values())

        # Specs
        specs = {}
        for name, section in self._project_settings.get_sections("spec").items():
            specs[name] = {
                'run_list': section.get_list('run_list')
            }
        if specs:
            manifest['specs'] = specs

        return manifest

    def set_default_lockers(self, lockers):
        import cyclecli
        config_file = cyclecli.find_config_file()
        config_dict = projects.config.read_config(config_file)

        proj_section_name = "project %s" % self.name
        config_dict.ensure_section(proj_section_name)
        if lockers:
            config_dict[proj_section_name].set_list("default_locker", lockers)
        else:
            if "default_locker" in config_dict[proj_section_name]:
                del config_dict[proj_section_name]["default_locker"]
            if len(config_dict[proj_section_name]) == 0:
                del config_dict[proj_section_name]

        projects.config.write_config(config_file, config_dict)

    def _get_locker(self, locker):
        return self._project_settings.get("locker %s" % locker)

    def get_cluster_definition(self, template, name):
        if template is None:
            templates = self.get_templates(template)

            if len(templates) == 0:
                raise ProjectClusterNotFound("No cluster templates found in project %s" % self.name)

            if len(templates) > 1:
                raise ProjectAmbiguousDefault('More than one cluster template found in project %s. '
                                              'Please use the --template option to specify which one to use.' % self.name)
            template_path = templates[0]
        else:
            template_path = assert_and_resolve_template_path_exists(template)

        return ClusterDefinition(name, template_path)

    def get_templates(self, template=None):
        '''Find cluster templates that exist in project'''
        templatedir = os.path.join(self._project_root, 'templates')
        if not os.path.exists(templatedir):
            return []

        all_templates = glob.glob("%s/*.txt" % templatedir)
        if template:
            filtered = [x for x in all_templates if os.path.basename(x) == template]
            if not filtered:
                raise ProjectClusterNotFound("No cluster templates found in project %s matching name %s" % (self.name, template))
            return filtered
        return all_templates

    def get_default_lockers(self):

        # There are no default lockers when running from jython (CycleCloud)
        if __IS_JYTHON__:
            return None, []

        import cyclecli
        config_file = cyclecli.find_config_file()
        config_dict = projects.config.read_config(config_file)

        proj_section_name = "project %s" % self.name
        config_dict.ensure_section(proj_section_name)
        lockers = config_dict[proj_section_name].get_list("default_locker", [])
        global_default = False

        if not lockers:
            config_dict.ensure_section("cyclecloud")
            lockers = config_dict["cyclecloud"].get_list("default_project_locker", [])
            if lockers:
                global_default = True

        return global_default, lockers

    @staticmethod
    def _valid_url(s):
        # this is a quick and dirty check to see if a given string s can be handled by pogo
        # We check for a colon in it so that we ensure it's actually a url like az://, gs:// etc
        # Pogo returns true for plain strings like "foo.txt" as that is technically a valid "file" url. In this
        # case we only want valid to be file:// urls

        if __IS_JYTHON__:
            if ":" in s:
                return pogo.handles_url(s)
            else:
                return False

        else:
            s = s.lower()
            return s.startswith("http://") or s.startswith("https://")

    def _validate_lockers(self, locker_names):
        if locker_names:
            if __IS_JYTHON__:
                from application import datastore, expressions

            else:
                import cyclecli
                from cyclecli import expressions
                datastore = cyclecli.get_datastore()

            # Remove URLs, we dont' have to validate these
            locker_names = [name for name in locker_names if not Project._valid_url(name)]

            name_expr = expressions.attributeIn("Name", locker_names)

            fetched_locker_records = datastore.find("Cloud.Locker", name_expr)
            fetched_locker_names = [r["Name"] for r in fetched_locker_records]

            # Add locally defined lockers
            fetched_locker_names += [locker for locker in self.local_lockers if locker in locker_names ]

            # If the locker names passed in don't match the fetched lockers or the locally defined lockers
            # show a list of available lockers
            if set(locker_names) != set(fetched_locker_names):
                valid_locker_records = datastore.find("Cloud.Locker", "Hidden!==true")
                valid_locker_names = [r["Name"] for r in valid_locker_records] + self.local_lockers
                if valid_locker_names:
                    print("Valid lockers: %s" % ", ".join(valid_locker_names))
                raise Exception("Unable to find all lockers.")

    def add_spec(self, spec):
        spec_dir = os.path.join(self._project_root, "specs", spec)
        if os.path.exists(spec_dir) and os.listdir(spec_dir) != []:
            raise Exception("Spec %s already exists in project!" % spec)

        skel = [
            ("specs", spec, "chef", "site-cookbooks"),
            ("specs", spec, "chef", "roles"),
            ("specs", spec, "chef", "data_bags"),
            ("specs", spec, "cluster-init", "scripts"),
            ("specs", spec, "cluster-init", "tests"),
            ("specs", spec, "cluster-init", "files")]

        for s in skel:
            path = os.path.join(self._project_root, *s)
            if not os.path.exists(path):
                os.makedirs(path)

        # Kinda crappy, but lets write some quick 'n dirty readme files
        path = os.path.join(self._project_root, "specs", spec, "cluster-init", "scripts")
        with open(os.path.join(path, "README.txt"), "w") as f:
            text = """
Files in this directory are executed on the host in alphabetical order.
It is recommended that files are named start with digits to ensure they
are executed in the correct order, example:
    - 000_run_me_first.sh
    - 001_run_me_second.sh

Allowable file extensions on Linux: .sh
Allowable file extensions on Windows: .bat, .cmd, .exe
            """
            f.write(text)
        path = os.path.join(self._project_root, "specs", spec, "cluster-init", "tests")
        with open(os.path.join(path, "README.txt"), "w") as f:
            text = """
Files in this directory contains tests that will be run at cluster start
when in testing mode. Please see the official documentation for more information
on cluster testing.
            """
            f.write(text)

        path = os.path.join(self._project_root, "specs", spec, "cluster-init", "files")
        with open(os.path.join(path, "README.txt"), "w") as f:
            text = """
Files in this directory are automatically synced to any node using this spec. Content here
can be anything from software packages to config files. Scripts can be used to install
software packages or move files into the appropriate location on the node.
            """
            f.write(text)

    def download(self, lockers):
        """ Downloads blobs from a remote locker

        This is used for cases when someone initially 'git clones' a project and has no blobs. If they were previously
        uploaded to a locker, one can `project download` the blobs into the local directory

        """
        self._validate_lockers(lockers)

        if not lockers:
            _, lockers = self.get_default_lockers()

        if not lockers:
            raise Exception("No locker specified!")

        success = True

        for locker in lockers:
            url, config = self._get_locker_url_and_config(locker)

            if __IS_JYTHON__:
                blobs_by_name = {}
                for blob in pogo.list(pogo.normalize_url(pogo.join_url(url, "blobs")), recursive=True, config=config):
                    if not blob.is_directory:
                        blobs_by_name[blob.relative_name] = blob

                blobs_to_download = []
                for section in self._project_settings.get_sections('blobs').values():
                    for pattern in section.get_list("files"):
                        matches = fnmatch.filter(list(blobs_by_name.keys()), pattern)
                        for match in matches:
                            blobs_to_download.append(match)

                # Actually transfer the files
                for filename in blobs_to_download:
                    src = pogo.normalize_url(pogo.join_url(url, "blobs", filename.strip()))
                    dst = os.path.join(self._project_root, "blobs", filename.strip())
                    logger.info("Syncing %s to %s", src, dst)
                    try:
                        if not pogo.sync(src, dst, src_config=config):
                            success = False
                    except Exception as e:
                        if not hasattr(e, "code") or e.code != "Object-Not-Found":
                            raise
                        logger.error("%s was not able to be downloaded (does not exist)", src)
                        success = False
                    except:
                        raise

            else:
                src_blobs_url = "/".join([url, "blobs"]) + "/" + config["sas_token"]
                dst_blobs_dir = os.path.join(self._project_root, "blobs") + os.sep
                exit_code = subprocess.call([_get_azcopy_path(), "sync", src_blobs_url, dst_blobs_dir])
                success = exit_code == 0

        return success

    def build(self, build_dir=None):
        """ Build the project locally 

            Params:
              build_dir - the destination to put the resulting build files (default: PROJECT_ROOT/build)
        """
        # Build directory is whatever the user passed in or $PROJECT/build
        if build_dir is None:
            build_dir = self.build_dir

        # Buid to $BUILD/<project>
        build_dir = os.path.join(build_dir, self.name)
        logger.info("Building to %s" % build_dir)

        # Clean the destination
        if os.path.isdir(build_dir):
            shutil.rmtree(build_dir)

        os.makedirs(build_dir)

        # 1.) Copy all the "regular" directories (anything not chef)
        specs_dir = os.path.join(self._project_root, "specs")
        copyable_directories = get_specs_uploadable_dirs(specs_dir)
        for (full_path, rel_path) in copyable_directories:
            shutil.copytree(full_path, os.path.join(build_dir, rel_path))

        # 2.) Chef is a bit of a special case, we zip it and copy it 
        self._package_chef(chef_packaging_dir=build_dir, clean_package_dir=False)

        # 3.) Generate manifest
        manifest = self._generate_manifest()

        # 4.) Write the manifest!
        with open(os.path.join(build_dir, "manifest.json"), "w") as f:
            f.write(json.dumps(manifest, indent=4, sort_keys=True))

    def upload(self, lockers):
        self._validate_lockers(lockers)

        if not lockers:
            _, lockers = self.get_default_lockers()

        if not lockers:
            raise Exception("No locker specified!")

        self.build()

        for locker in lockers:
            url, config = self._get_locker_url_and_config(locker)

            # 1. Copy project from $BUILD_DIR/$VERSION to URL/projects/$NAME/$VERSION w/ delete missing
            project_dir = os.path.join(self.build_dir, self.name) + os.sep
            dst_url = "/".join([url, self.version]) + "/"
            logger.info("Syncing '%s' to '%s'", project_dir, dst_url)

            if __IS_JYTHON__:
                sync_success = pogo.sync(project_dir, dst_url, delete_removed=True, dst_config=config)
                if not sync_success:
                    return False
            else:
                az_copy_path = _get_azcopy_path()
                dst_url += config["sas_token"]
                exit_code = subprocess.call([az_copy_path, "sync", project_dir, dst_url, "--delete-destination", "true"])
                if exit_code != 0:
                    return False

            # 2. Copy blobs from $PROJECT/blobs to $URL/projects/$NAME/$BLOBS without deletions
            blobs_dir = os.path.join(self._project_root, "blobs")
            files_to_sync = []

            # Read the built manfiest
            with open(os.path.join(self.build_dir, self.name, "manifest.json")) as f:
                manifest = json.load(f)
            for blob in manifest.get("blobs", []):
                src = os.path.join(blobs_dir, blob['path'])
                dst = "/".join([url, "blobs", blob['path']])

                if os.path.exists(src):
                    files_to_sync.append((src, dst))

            for src, dst in files_to_sync:
                if __IS_JYTHON__:
                    sync_success = pogo.sync(src, dst, delete_removed=False, dst_config=config)
                    if not sync_success:
                        return False
                else:
                    az_copy_path = _get_azcopy_path()
                    dst += config["sas_token"]
                    if subprocess.check_output([az_copy_path, "list", dst]).strip():
                        action = "sync"
                    else:
                        action = "copy"
                    exit_code = subprocess.call([az_copy_path, action, src, dst])
                    if exit_code != 0:
                        return False

            return True

    def _get_locker_url_and_config(self, locker, use_staging=False):
        local_lockers = set(self.local_lockers)

        if locker in local_lockers:
            root_url = self._get_locker(locker).get("location")

            config = None

        elif self._valid_url(locker):
            root_url = locker

            config = None

        else:
            if __IS_JYTHON__:
                from cloud.locker import credentials as locker_creds
                info = locker_creds.getLockerCreds(locker)
                root_url = info["matches"][0]
                config = info

            else:
                import cyclecli
                from cyclecli import UserError
                from cyclecli import expressions

                s = cyclecli.get_session(cyclecli.get_config(), use_config_url=True)
                try:
                    r = s.get("/cloud/api/lockers/%s/credentials" % locker)
                    info = json.loads(r.text)
                    root_url = info["matches"][0]
                    config = info

                except Exception as e:
                    if hasattr(e, "code") and e.code != 404:
                        raise
                    # ignore 404, attempt to query locker raw, so the user gets some useful output

                    datastore = cyclecli.get_datastore()
                    locker_records = datastore.find("Cloud.Locker", 'Name===%s' % expressions.quote(locker))
                    if len(locker_records) == 0:
                        raise UserError("Unable to find locker: %s" % locker)
                    root_url = locker_records[0]["Location"].rstrip("/")
                    config = None

        url_parts = urllib.parse.urlsplit(root_url)
        url_parts = [url_parts.scheme, url_parts.netloc, url_parts.path, url_parts.query, url_parts.fragment]

        # cyclecloud stages projects in a user's storage account in a slightly different path
        # in order for a user to iterate on project development, they may want to
        # upload their project directly to the staging path
        url_parts[2] = url_parts[2].rstrip("/")
        if use_staging:
            url_parts[2] = "/".join([url_parts[2], "cache", "projects", self.name])
        else:
            url_parts[2] = "/".join([url_parts[2], "projects", self.name])

        if not __IS_JYTHON__:
            if url_parts[0].lower() == "az":
                # convert pogo's az:// url to the formal http:// form
                if config and "environment" in config and "storage_suffix" in config["environment"]:
                    storage_suffix = config["environment"]["storage_suffix"]
                else:
                    logger.warning("Unable to locate environment.storage_suffix information, assuming '.core.windows.net'")
                    storage_suffix = '.core.windows.net'

                url_parts[0] = "https"
                url_parts[1] += ".blob" + storage_suffix

            # adjust config so callers have an easier time with simple string joins
            # ensuring sas_token always exists and if not an empty string then it always starts with a question mark
            if config is None:
                config = {}

            if url_parts[3]: # if there is a query string then it becomes the sas_token
                config["sas_token"] = url_parts[3]
                url_parts[3] = ""

            if not config.get("sas_token"):
                config["sas_token"] = ""
            elif not config["sas_token"].startswith("?"):
                config["sas_token"] = "?" + config["sas_token"]

        url = urllib.parse.urlunsplit(url_parts)

        return url, config

    def _package_chef(self, chef_packaging_dir=None, clean_package_dir=True):
        specs_dir = os.path.join(self._project_root, "specs")

        if chef_packaging_dir is None:
            chef_packaging_dir = os.path.join(self._project_root, ".project", "packaged_chef")

        if os.path.exists(chef_packaging_dir) and clean_package_dir:
            shutil.rmtree(chef_packaging_dir)

        chef_dirs = []

        for dirpath, dirnames, _ in os.walk(specs_dir):
            if os.path.basename(dirpath) == "chef":
                for d in dirnames:
                    if d in ["site-cookbooks", "roles", "data_bags"]:
                        src_dir = os.path.join(dirpath, d)

                        # Only package non-empty directories
                        if os.listdir(src_dir) == []:
                            continue
                        rel_src_dir = src_dir[len(specs_dir) + 1:]
                        dst_dir = os.path.join(chef_packaging_dir, dirpath[len(specs_dir) + 1:])
                        dst_file = os.path.join(dst_dir, d + ".tgz")
                        logger.info("Packaging '%s' into '%s'", src_dir, dst_file)
                        if not os.path.exists(dst_dir):
                            os.makedirs(dst_dir)
                        with tarfile.open(dst_file, 'w:gz') as t:
                            t.add(src_dir, arcname=d)
                        chef_dirs.append(rel_src_dir.replace(os.sep, "/"))

        return chef_packaging_dir, chef_dirs

    def _save_settings(self):
        project_settings = os.path.join(self._project_root, "project.ini")

        projects.config.write_config(project_settings, self._project_settings)

    def generate_template(self, dest, internal=False):
        """ Generate a template based on the "type" of project and write the template to a file """
        if self.type is None:
            raise Exception("No project type specified, cannot generate template")

        if self.type.lower() == "application":
            from projects.templates import APPLICATION_TEMPLATE as template
        elif self.type.lower() == "scheduler":
            from projects.templates import SCHEDULER_TEMPLATE as template
        else:
            raise Exception("Unsupported project type %s!" % self.type)

        # Write the template to disk
        dest = os.path.expanduser(dest)
        dirname = os.path.dirname(dest)
        if dirname and not os.path.isdir(dirname):
            os.makedirs(dirname)
        with open(dest, 'w') as f:
            f.write(self._format_template(template, internal))

    def _format_template(self, template, internal=False):
        """ Given a template string, formats the template with the appropriate variables """
        description = "<p>Insert template description here</p>"
        description_file = os.path.join(self._project_root, 'description.html')
        if os.path.isfile(description_file):
            with open(description_file) as f:
                description = f.read()

        # If this is an internal template, we use the cyclecloud/ prefix to denote it's "installed" inside CC
        prefix = ""
        if internal:
            prefix = "cyclecloud/"

        # Generate configuration references and parameters
        configuration_references = []
        configuration_parameters = []
        for parameter_name, config in self._project_settings.get_sections("config").items():
            parameter_variable = "configuration_%s" % parameter_name.replace(".", "_")

            # Configuration reference is a simple  parameter_name = parameter_variable            
            configuration_reference = "%s = $%s" % (parameter_name, parameter_variable)

            # Param section is generated use the param name, then all the value specified underneath it
            parameter = "[[[parameter %s]]]\n" % parameter_variable
            for k, v in config.items():
                parameter += "%s = %s\n" % (k, v)

            configuration_references.append(configuration_reference)
            configuration_parameters.append(parameter)

        return template.format(name=self.name, 
                              version=self.version, 
                              label=self.label, 
                              description=description,
                              configuration_references="\n".join(configuration_references),
                              configuration_parameters="\n".join(configuration_parameters),
                              prefix=prefix)

    @property
    def name(self):
        return self._project_settings.get("project", {}).get("name")

    @property
    def version(self):
        return self._project_settings.get("project", {}).get("version", "1.0.0")

    @property
    def label(self):
        """ Label is the specified label, else the project name """
        return self._project_settings.get("project", {}).get("label", self.name)

    @property
    def type(self):
        return self._project_settings.get("project", {}).get("type")

    @property
    def autoupgrade(self):
        return self._project_settings.get("project", {}).get_boolean("autoupgrade", False)

    @property
    def local_lockers(self):
        l = []
        for k in list(self._project_settings.keys()):
            if k.startswith("locker "):
                l.append(k[7:])
        return l

    @property
    def build_dir(self):
        return os.path.join(self._project_root, "build")

    def __str__(self):
        s = "Name: %s" % self.name
        if self.version is not None:
            s += "\nVersion: %s" % self.version

        global_default, default_lockers = self.get_default_lockers()

        if default_lockers:
            if len(default_lockers) > 1:
                s += "\nDefault Lockers: %s" % ", ".join(default_lockers)
            else:
                s += "\nDefault Locker: %s" % ", ".join(default_lockers)

            if global_default:
                s += " (global default)"

        return s
