import os
import socket
import subprocess
import re
import platform

from cyclecloud.util import urlquote
from cyclecloud.crypto import fingerprint_sha256, is_private_pem


_TUNNEL_TIMEOUT = 60
IS_WINDOWS = platform.system().lower() == "windows"


def rdp_to_instance(clustername, nodename, hostname, username, password, rdp_port=None, 
        command_template=None, key_lookup_path=None, bastion_host=None, 
        bastion_user=None, bastion_keyfile=None, bastion_ssh_port=None, 
        bastion_fingerprint=None, bastion_preferred_key_name=None):
    if rdp_port is None:
        rdp_port = 3389

    if command_template is None:
        command_template = get_rdp_command_template(use_tunnel=bastion_host is not None)

    if key_lookup_path is None:
        key_lookup_path = os.path.join(os.path.expanduser("~"), ".ssh")

    if bastion_keyfile is None and bastion_fingerprint is not None:
        bastion_keyfile = lookup_keypair_location(bastion_fingerprint, 
            key_lookup_path, preferred_key_name=bastion_preferred_key_name)

    if bastion_host:
        if bastion_ssh_port is None:
            bastion_ssh_port = 22
        if bastion_user is None:
            bastion_user = "cyclecloud"

        local_port = _get_ephemeral_port()
        args = ["ssh"]

        args.extend(["-p", str(bastion_ssh_port)])

        _disable_host_key_checking(args)

        if bastion_keyfile:
            args.extend(["-i", bastion_keyfile])

        args.extend(["-f", "%s@%s" % (bastion_user, bastion_host)])

        args.extend(["-L", "%s:%s:%s" % (local_port, hostname, rdp_port)])

        args.append("sleep %s" % _TUNNEL_TIMEOUT)

        command = _replace(command_template, {
            "HOSTNAME": "%s:%s" % ("localhost", local_port), 
            "USERNAME": username, "PASSWORD": password})

        command = "%s && %s" % (subprocess.list2cmdline(args), command)

        connect_msg = "Connecting to %s@%s (%s %s) using RDP through SSH bastion %s@%s" % (username, hostname, clustername, nodename, bastion_user, bastion_host)
    else:
        command = _replace(command_template, {
            "HOSTNAME": "%s:%s" % (hostname, rdp_port), 
            "USERNAME": username, "PASSWORD": password})

        connect_msg = "Connecting to %s@%s (%s %s) using RDP" % (username, hostname, clustername, nodename)

    print(connect_msg)
    # print "Command line: %s" % command

    subprocess.check_call(command, shell=True)


def ssh_to_instance(clustername, nodename, hostname, username, ssh_port=None, 
        keyfile=None, fingerprint=None, key_lookup_path=None, 
        preferred_key_name=None, bastion_host=None, bastion_user=None,
        bastion_keyfile=None, bastion_ssh_port=None, bastion_fingerprint=None,
        bastion_preferred_key_name=None):
    if ssh_port is None:
        ssh_port = 22

    if key_lookup_path is None:
        key_lookup_path = os.path.join(os.path.expanduser("~"), ".ssh")

    if keyfile is None and fingerprint is not None:
        keyfile = lookup_keypair_location(fingerprint, key_lookup_path, preferred_key_name=preferred_key_name)

    if bastion_keyfile is None and bastion_fingerprint is not None:
        bastion_keyfile = lookup_keypair_location(bastion_fingerprint, 
            key_lookup_path, preferred_key_name=bastion_preferred_key_name)

    if bastion_keyfile:
        bastion_keyfile = os.path.abspath(os.path.expanduser(bastion_keyfile))
        if not os.path.exists(bastion_keyfile):
            print("Warning: bastion keypair %s not found." % bastion_keyfile)
            bastion_keyfile = None

    if keyfile:
        keyfile = os.path.abspath(os.path.expanduser(keyfile))
        if not os.path.exists(keyfile):
            print("Warning: keypair %s not found. Connection will assume it is the default key or added to ssh-agent." % keyfile)
            keyfile = None
    else:
        if fingerprint is None:
            print("Warning: no keypair specified. Connection will assume it is the default key or added to ssh-agent.")
        else:
            print("Warning: no keypair in %s matching fingerprint %s. Connection will assume it is the default key or added to ssh-agent." % (key_lookup_path, fingerprint))

    if bastion_host:
        if not bastion_user:
            bastion_user = username
        if not bastion_keyfile:
            bastion_keyfile = keyfile
        if not bastion_ssh_port:
            bastion_ssh_port = ssh_port

        args = ["ssh"]
        if keyfile:
            args.extend(["-i", keyfile])

        args.extend(["-p", str(ssh_port)])
        _disable_host_key_checking(args)

        inner_cmd = ["ssh"]
        if bastion_keyfile:
            if IS_WINDOWS:
                # KLUDGE: On Windows, backslashes seem to be misinterpreted and
                #         stripped by ProxyCommand. Use forward slashes instead.
                inner_cmd.extend(["-i", bastion_keyfile.replace("\\", "/")])
            else:
                inner_cmd.extend(["-i", bastion_keyfile])

        # Host key checking seems to break cli in the ProxyCommand, unless we 
        # pass in a Null hosts file
        _disable_host_key_checking(inner_cmd)
        inner_cmd.extend(["-q", "%s@%s" % (bastion_user, bastion_host), "-W", "\\%h:" + str(bastion_ssh_port)])
        
        args.extend(["-o", "ProxyCommand=%s" % subprocess.list2cmdline(inner_cmd)])

        args.append("%s@%s" % (username, hostname))

        connect_msg = "Connecting to %s@%s (%s %s) through SSH bastion at %s@%s" % (username, hostname, clustername, nodename, bastion_user, bastion_host)
    else:
        args = ["ssh"]
        if keyfile:
            args.extend(["-i", keyfile])

        args.extend(["-p", str(ssh_port)])
        _disable_host_key_checking(args)

        args.append("%s@%s" % (username, hostname))

        connect_msg = "Connecting to %s@%s (%s %s) using SSH" % (username, hostname, clustername, nodename)
    
    print(connect_msg)
    # print "Command line: %s" % subprocess.list2cmdline(args)

    subprocess.call(args)


def _disable_host_key_checking(args):
    '''Utility func to add the arguments to disable strict host key checking'''
    args.extend([
        # Don't check known hosts file
        "-o", "StrictHostKeyChecking=no", 
        # Don't modify known hosts file
        "-o", "UserKnownHostsFile=%s" % ("NUL" if IS_WINDOWS else "/dev/null"),
        # Disable 'Permanently added __ to the list of known hosts message
        "-o", "LogLevel=ERROR"])


def lookup_keypair_location(fingerprint, lookup_path, preferred_key_name=None):
    '''
    Look for a keypair matching the given fingerprint in the given path.
    If no matching keypair is found, returns None
    '''

    # Right now only sha256 fingerprints are supported
    if "sha256" not in fingerprint:
        print("Warning: No SHA256 fingerprint found. Unable to look up keypair.")
        return None

    # Check the preferred file name first
    if preferred_key_name is not None:
        f = _lookup(fingerprint, lookup_path, preferred_key_name)
        if f is not None:
            return f

    # Now check the rest of the files in the directory
    for filename in os.listdir(lookup_path):
        if filename == "authorized_keys":
            # Skip authorized_keys file to avoid interpreting a single public
            # key in this file incorrectly
            continue
        if filename == preferred_key_name:
            # Already tried the preferred file
            continue
        f = _lookup(fingerprint, lookup_path, filename)
        if f is not None:
            return f

    return None


def _lookup(fingerprint, lookup_path, filename):
    keyfile = os.path.join(lookup_path, filename)
    if os.path.isfile(keyfile):
        with open(keyfile, "rb") as f:
            keydata = f.read()

        try:
            if "sha256" in fingerprint and is_private_pem(keydata) and fingerprint_sha256(keydata) == fingerprint["sha256"]:
                return os.path.abspath(keyfile)
        except Exception:
            # Ignore parsing errors. Some files in this dir probably won't 
            # be keys or may be keys with pass-phrases, but pycrypto doesn't
            # raise a single exception type that we can easily handle for
            # these cases.
            pass


def get_rdp_command_template(use_tunnel=False):
    sys_name = platform.system().lower()

    connect_info = "\nConnection Info\n---------------\nHost: ${HOSTNAME}\nUser: ${USERNAME}\nPassword: ${PASSWORD}"

    if use_tunnel:
        connect_info = connect_info + "\n\n** RDP connections through the bastion must be established within %s seconds **" % _TUNNEL_TIMEOUT

    if sys_name == "windows":
        if use_tunnel:
            cmd = 'cmdkey /generic:TERMSRV/localhost /user:"${USERNAME}" /pass:"${PASSWORD}" >nul & echo Opening remote desktop connection through tunnel & mstsc /v:${HOSTNAME}'
        else:
            cmd = 'cmdkey /generic:TERMSRV/${HOSTNAME} /user:"${USERNAME}" /pass:"${PASSWORD}" >nul & echo Opening remote desktop connection to ${USERNAME}@${HOSTNAME} & mstsc /v:${HOSTNAME}'
    elif sys_name == "darwin":
        # standard RDP URI format
        cmd = 'echo "' + connect_info + '" && open "rdp://full%20address=s:${HOSTNAME}&username=s:${USERNAME:url}&prompt%20for%20credentials%20on%20client=i:1"'
        # CoRD Format - in case we ever want to add it back in
        # rdp_command = "open rdp://${USERNAME:url}:${PASSWORD:url}@${HOSTNAME}"
    elif sys_name == 'linux':
        cmd = 'echo "%s"' % connect_info
    else:
        raise Exception("Unable to determine a valid RDP command for platform %s" % sys_name)

    return cmd


def _replace(s, d):
    '''Interpolates the values given, into placeholders like ${VAR1}. Supports an optional ${VAR:url} designation
    to URL-encode the values before substitution.'''
    pattern = re.compile(r"\$\{(.+?)\}")

    def r(k):
        parts = k.group(1).split(":", 1)
        key = parts[0]

        encoding = None
        if len(parts) == 2:
            encoding = parts[1]

        value = d.get(key)
        if encoding == "url":
            value = urlquote(value)

        return value

    return pattern.sub(r, s)


def _get_ephemeral_port():
    '''Gets an unused ephemeral port. Note that there is no guarantee the port
    will remain unused after this method is called, so there is a race condition
    if code simply tries to use this port assuming it is still free'''
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    
    # Bind to INADDR_ANY
    s.bind(('', 0))
    addr = s.getsockname()

    # Get the ephemeral port
    port = addr[1]

    s.close()

    return port
