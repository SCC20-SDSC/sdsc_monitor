import base64
import hashlib
import binascii
import re
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization


def is_private_pem(data):
    firstline = data.strip().split(b'\n')[0]
    return re.match(b'^-----BEGIN (DSA|RSA) PRIVATE KEY*', firstline)


def is_public_pem(data):
    firstline = data.strip().split(b'\n')[0]
    return re.match(b'^-----BEGIN PUBLIC KEY*', firstline)


def is_public_openssh_key(data):
    firstline = data.strip().split(b'\n')[0]
    return re.match(b'^ssh-(rsa|dss|dsa)*', firstline)


def fingerprint_sha256(data):
    '''
    Given a private or public key body, returns a SHA256 fingerprint string.
    May raise ValueError if the given file type cannot be determined
    '''

    if is_private_pem(data):
        key = serialization.load_pem_private_key(data, password=None, backend=default_backend()).public_key()
    elif is_public_pem(data):
        key = serialization.load_pem_public_key(data, password=None, backend=default_backend())
    elif is_public_openssh_key(data):
        key = serialization.load_ssh_public_key(data, backend=default_backend())
    else:
        raise ValueError("Cannot determine format of key")

    rsaKey = key.public_bytes(encoding=serialization.Encoding.OpenSSH,
                              format=serialization.PublicFormat.OpenSSH).split()[1]

    return _sha256_fingerprint_from_pub_key(rsaKey)


def _sha256_fingerprint_from_pub_key(openssh_publickey_contents):
    data = bytes(openssh_publickey_contents)
    digest = hashlib.sha256(binascii.a2b_base64(data)).digest()
    encoded = base64.b64encode(digest).rstrip(b'=')
    return encoded.decode('utf-8')
