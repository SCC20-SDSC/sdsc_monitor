import cyclecli
from cyclecli.datastore import CaseInsensitiveDict
from cyclecli import UserError
from cyclecli import YES_NO_SET, YES_SET
import sys
import json
import re
import os
import os.path


def modify_account(account_name=None, dryrun=False, input_file=None, output_file=None, initial_config=None):
    '''Prompts the user for information about a new account, and creates it if successful.'''

    form_name = "type:Cloud.ProviderAccount:create" if account_name is None else "type:Cloud.ProviderAccount:edit"
    if initial_config is not None:
        # The first time an Account is created during cyclecloud initialize the
        # config file does not yet exist
        config = initial_config
    else:
        config = cyclecli.get_config()

    s = cyclecli.get_session(config)

    params = None
    if input_file is not None:
        with open(input_file, "r") as f:
            params = json.load(f)
    else:
        if dryrun:
            print("** Note: this will not actually create the account. It will validate the information only.\n")

        params = _get_params(form_name, account_name, config=config)
        print("")
    if output_file is not None:
        # write to disk
        with open(output_file, "w") as f:
            json.dump(params, f, sort_keys=True, indent=4)

    # now create the account
    url_params = {"format": "json", "name": form_name}
    if account_name:
        url_params["account"] = account_name
    if dryrun:
        url_params["validate_only"] = "true"

    r = s.post("%s/cloud/api/accounts" % config["url"], data=json.dumps(params), params=url_params)
    r.raise_for_status()
    results = json.loads(r.text)

    if len(results):
        for result in results:
            if (result.get("Status") or "ok") == "error":
                raise UserError(result.get("Message"))
    else:
        if dryrun:
            print("Account %s validated successfully" % params["Name"])
        elif account_name:
            print("Account %s updated successfully" % params["Name"])
        else:
            print("Account %s created successfully" % params["Name"])

    if output_file is not None:
        print("Parameters for account creation written to %s.\nYou can create a matching account later with `%s account create -f %s`" % (output_file, sys.argv[0], output_file))


def _get_params(form_name, account_name, config=None):
    if config is None:
        config = cyclecli.get_config()
    s = cyclecli.get_session(config)
    validate_url = "%s/cloud/api/validate_account" % config["url"]

    # start with an empty state
    state = CaseInsensitiveDict()

    while True:
        url_params = {"format": "json", "name": form_name}
        if account_name:
            url_params["account"] = account_name

        r = s.post(validate_url, data=json.dumps(state.get_dict()), params=url_params)
        r.raise_for_status()

        state = CaseInsensitiveDict(json.loads(r.text))

        params = state["Parameters"]
        form_param = state["CurrentParameter"]
        if form_param is None:
            break

        param_name = form_param["Name"]

        # hide params that start with "._"
        if param_name.startswith("._"):
            state[param_name] = None
            continue

        text = None
        if form_param.get("Text"):
            text = form_param["Text"]

        default_value = params.get(param_name)
        if default_value is None:
            default_value = form_param.get("DefaultValue")

        label = form_param.get("Prompt", param_name) or form_param.get("Label", param_name) or ""
        if label.endswith("?"):
            label += " "
        else:
            label += ": "

        password = False
        valid_selections = None

        prompt = True
        parameter_type = (form_param.get("ParameterType") or "").lower()
        if parameter_type == "password":
            password = True
        elif parameter_type == "boolean":
            valid_selections = YES_NO_SET
            default_value = "y" if default_value else "n"
        elif parameter_type == "environment":
            valid_selections = YES_NO_SET
            default_value = "y" if default_value else "n"

            if text is not None:
                text = _substitute(text, os.environ)

            # make sure they are all defined
            found_all = True
            for var in form_param.get("Variables"):
                if os.getenv(var) is None:
                    found_all = False
                    break
            if not found_all:
                # no need to ask, and report nothing to the server
                prompt = False
                text = None
                params[param_name] = None

        elif parameter_type == "filesystem":
            valid_selections = YES_NO_SET
            default_value = "y" if default_value else "n"

            # make sure they all exist
            found_all = True
            for filename in list(form_param.get("Files").values()):
                filename = os.path.expanduser(filename)
                if not os.path.exists(filename):
                    found_all = False
                    break
            if not found_all:
                # no need to ask, and report nothing to the server
                prompt = False
                text = None
                params[param_name] = None

        if text is not None:
            print(text)

        while prompt:
            params[param_name] = cyclecli.prompt(label, required=form_param.get("Required", False),
                                                 default_value=default_value, password=password, valid_selections=valid_selections)

            if params[param_name] == "":
                params[param_name] = None
            
            if parameter_type == "boolean":
                params[param_name] = params[param_name] in YES_SET
            elif parameter_type == "file":
                filename = params[param_name]
                filename = os.path.expanduser(filename)
                if not os.path.exists(filename):
                    print("ERROR: File %s does not exist" % filename)
                    continue
                destination = form_param.get("DestinationParameter")
                with open(filename, "r") as f:
                    params[destination] = f.read()
            elif parameter_type == "environment":
                if params[param_name] in YES_SET:
                    env_dict = {}
                    for var in form_param.get("Variables"):
                        env_dict[var] = os.getenv(var)
                    params[param_name] = env_dict
                else:
                    params[param_name] = None
            elif parameter_type == "filesystem":
                if params[param_name] in YES_SET:
                    fs_dict = {}
                    for key, filename in form_param.get("Files").items():
                        filename = os.path.expanduser(filename)
                        if os.path.exists(filename):
                            with open(filename, "r") as f:
                                fs_dict[key] = f.read()

                    params[param_name] = fs_dict
                else:
                    params[param_name] = None

            break

    return state["Parameters"].get_dict()


def _substitute(string, values):

    pattern = re.compile(r'\$([a-z0-9_]+)', re.IGNORECASE)

    def replace(match):
        s = match.group(1)
        if s in values:
            return values[s]
        return s

    return pattern.sub(replace, string)
