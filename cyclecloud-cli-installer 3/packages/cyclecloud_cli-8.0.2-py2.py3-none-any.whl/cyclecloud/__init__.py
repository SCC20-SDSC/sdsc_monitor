from __future__ import absolute_import, print_function

import copy
import sys
import os
import os.path
import time
import json
import logging
import re

import cyclecli
from cyclecli import BaseCommand, ConfigSection, ArgumentError, UserError, records
from cyclecloud import account, commands
from cyclecloud.connect import ssh_to_instance, rdp_to_instance
import cyclecloud.util
from cyclecloud.util import CaseInsensitiveDict, urlquote, raise_if_needed
import cyclecloud.api

logging.basicConfig(level=logging.DEBUG, stream=sys.stderr, format="%(message)s")

logger = logging.getLogger(__name__)

_application_name = "CycleCloud"
from cyclecloud.version import __version__

# how long in seconds to wait for CCS to begin the orchestration process so users' changes are shown
STANDARD_COMMAND_WAIT_TIME = 30

# we ask for new Cloud.Instance types only now
cloud_instances_setting = "true"


def _listclusters(config, options):
    s = cyclecli.get_session(config)
    params = {}
    params['summary'] = "true"
    params['cloud_instances'] = cloud_instances_setting
    if getattr(options, "long", False):
        del params['summary']
    if getattr(options, "templates", True):
        params['templates'] = "true"

    # TODO: change to /cloud/api/clusters
    r = cyclecloud.util.get(s, config["url"] + "/cloud/clusters", params=params)
    raise_if_needed(r)

    results = [CaseInsensitiveDict(cluster) for cluster in json.loads(r.text)]
    results = sorted(results, key=lambda c: c.get('ClusterName', '').lower())

    for cluster in results:
        instance_map = {}
        if "Instances" in cluster:
            cluster["Instances"] = [CaseInsensitiveDict(ad) for ad in cluster["Instances"]]
            instance_map = dict([(ad["InstanceId"], ad) for ad in cluster["Instances"]])

        _printcluster(cluster, instance_map, cluster["ClusterName"])


def _showcluster(config, name, options):
    s = cyclecli.get_session(config)
    params = {}

    params['summary'] = "true"
    params['cloud_instances'] = cloud_instances_setting
    if getattr(options, "long", False):
        del params['summary']

    if getattr(options, "recursive", False):
        params['recursive'] = "true"

    r = cyclecloud.util.get(s, "%s/cloud/api/clusters/%s" % (config["url"], urlquote(name)), params=params)
    raise_if_needed(r)

    results = [CaseInsensitiveDict(cluster) for cluster in json.loads(r.text)]
    results = sorted(results, key=lambda c: c['ClusterName'].lower())

    for cluster in results:
        instance_map = {}
        if "Instances" in cluster:
            cluster["Instances"] = [CaseInsensitiveDict(ad) for ad in cluster["Instances"]]
            instance_map = dict([(ad["InstanceId"], ad) for ad in cluster["Instances"]])

        _printcluster(cluster, instance_map, cluster["ClusterName"])


class Tabulated(object):
    def __init__(self, col_count):
        self.min_widths = [0] * col_count
        self.rows = []
        self.col_count = col_count
        self.row_index = -1
        self.col_index = 0

    def add_row(self):
        self.rows.append([""] * self.col_count)
        self.row_index += 1
        self.col_index = 0

    def add_value(self, value):
        self.min_widths[self.col_index] = max(len(value), self.min_widths[self.col_index])
        self.rows[self.row_index][self.col_index] = value
        self.col_index += 1

    def print_table(self, prefix):
        for row in self.rows:
            print(prefix, end=' ')
            for col, value in enumerate(row):
                print(value.ljust(self.min_widths[col]), end=' ')
            print() 

def _printcluster(cluster, instance_map, clustername):

    cluster_state = cluster['State'].lower() if 'State' in cluster else 'off'

    # If the cluster is a 'template' we should display it as such to differentiate it from
    # startable clusters
    if 'IsTemplate' in cluster and cluster['IsTemplate']:
        cluster_state = "*template*"

    target_state = cluster['TargetState'].lower() if 'TargetState' in cluster else None
    if target_state is not None and target_state != cluster_state:
        target_state = ' -> %s' % target_state
    else:
        target_state = ''

    cluster_title = "%s : %s%s" % (clustername, cluster_state, target_state)
    sep = "".ljust(len(cluster_title), "-")
    print(sep)
    print(cluster_title)
    print(sep)
    # TODO: date!

    # zones = set([(ad.get("Zone", "unknown")) for ad in cluster["Instances"]])
    # print "Zone: %s" % ", ".join(zones)

    cluster_nodes = []
    cluster_node_arrays = []
    if "Nodes" in cluster:
        cluster_nodes = [CaseInsensitiveDict(node) for node in cluster["Nodes"]]
    if "NodeArrays" in cluster:
        cluster_node_arrays = [CaseInsensitiveDict(nodearray) for nodearray in cluster["NodeArrays"]]
    cluster["Nodes"] = cluster_nodes
    cluster["NodeArrays"] = cluster_node_arrays

    resource_group_dict = cluster.get("Azure", {}).get("ResourceGroups", {})
    resource_groups = set([v["ResourceGroup"] for v in resource_group_dict.values()])
    print("Resource group: %s" % ", ".join(resource_groups))

    print("Cluster nodes:")
    tabulated = Tabulated(5)

    node_map = {}
    for node in cluster_nodes:
        node_map[node["Name"]] = node

    node_names = list(node_map.keys())
    # sort by non-array node, then array node
    node_names.sort(key = lambda node_name: (node_map[node_name].get("Template") != node_name, node_name))

    for node_name in node_names:
        tabulated.add_row()

        node = node_map[node_name]
        instance = None
        instance_id = node.get("InstanceId")
        if instance_id:
            instance = instance_map.get(instance_id)
        else:
            instance_id = ""

        state = node.get("State", "Off")
    
        descriptions = []

        vm_name = ""
        hostname = "--"
        ip = "--"
        if instance:
            vm_name = instance.get("InstanceName") or ""
            if not vm_name and instance.get("ScalesetIndex") is not None:
                vm_name = "%s_%d" % (instance.get("Scaleset"), instance.get("ScalesetIndex"))
            hostname = instance.get("Hostname")
            if not hostname:
                hostname = instance.get("PrivateHostname") or "--"

            ip = instance.get("PrivateIp") or ""

        tabulated.add_value(node["Name"] + ":")
        tabulated.add_value(state)
        tabulated.add_value(hostname)
        tabulated.add_value(ip)
        tabulated.add_value(vm_name)

    tabulated.print_table("   ")

    phase_map = {}
    for phase in cluster["Phases"]:
        phase = CaseInsensitiveDict(phase)
        phase_map[phase["Name"]] = phase

    min_widths = [0]*5
    for node in cluster_node_arrays:
        min_widths[0] = max(len(node["Template"]), min_widths[0])

    min_widths[0] = min_widths[0] + 1

    array_node_count = 0
    if cluster_node_arrays:
        print("Cluster node arrays:")
        for array in cluster_node_arrays:
            state = "off"
            if "State" in array:
                state = array["State"]
                if state != "Started":
                    phases = array.get("ActivePhases", [])
                    phase_descriptions = []
                    if phases:
                        for phase_name in phases:
                            # bug 2823542 - transient bug where phase_name wasn't actually
                            # defined in the phase_map.
                            phase = phase_map.get(phase_name)
                            if phase and "Description" in phase:
                                phase_descriptions.append(phase["Description"])

                    state = state + " (" + ", ".join(phase_descriptions) + ")"

            print("    ", (array["Template"] + ":").ljust(min_widths[0]), array["Count"], "instances,", array["CoreCount"], "cores,", state)
            array_node_count = array_node_count + int(array["Count"])

    total_nodes = len(cluster["Nodes"]) + array_node_count
    print("Total nodes:", total_nodes)


def _terminate(config, name, options):
    cyclecloud.api.terminate_cluster(config, name, recursive=options.recursive)


def _deletecluster(config, name, options):
    cyclecloud.api.delete_cluster(config, name, recursive=options.recursive, force=options.force)


def _startcluster(config, name, options):
    cyclecloud.api.start_cluster(config, name, recursive=options.recursive,
                                 test_mode=options.test_mode)


def _retrycluster(config, name, options):
    cyclecloud.api.retry_cluster(config, name, recursive=options.recursive)


def _add_nodes(config, name, options):
    s = cyclecli.get_session(config)
    params = {}
    params['wait_time'] = STANDARD_COMMAND_WAIT_TIME
    if hasattr(options, "count"):
        params["count"] = options.count
    if hasattr(options, "fixed"):
        params["fixed"] = options.fixed
    if hasattr(options, "template") and options.template is not None:
        url = "%s/cloud/actions/add_node/%s/%s" % (config["url"], urlquote(name), urlquote(options.template))
    else:
        url = "%s/cloud/actions/add_node/%s" % (config["url"], urlquote(name))

    r = cyclecloud.util.post(s, url, params=params)
    raise_if_needed(r)


def _start_nodes(config, cluster_name, node_name, options):
    s = cyclecli.get_session(config)
    params = {}
    params["node_name"] = node_name
    params['wait_time'] = STANDARD_COMMAND_WAIT_TIME

    url = "%s/cloud/actions/start_node/%s" % (config["url"], urlquote(cluster_name))
    r = cyclecloud.util.post(s, url, params=params)
    raise_if_needed(r)


def _reboot_nodes(config, cluster_name, node_name, options):
    s = cyclecli.get_session(config)
    params = {}
    params["node_name"] = node_name

    url = "%s/cloud/actions/reboot_node/%s" % (config["url"], urlquote(cluster_name))
    r = cyclecloud.util.post(s, url, params=params)
    raise_if_needed(r)


def _prompt_for_filter_confirmation(config, options, cluster_name, method):
    """ TODO: Can we just create an options hash? """

    # Given the filtering options we already have (we assume they are the same between commands)
    # Add in some other info and run a _show_nodes to ask the user for confirmation before doing anything
    options.cluster = cluster_name
    options.format = 'tabular'
    options.attrs = 'Name,ClusterName,InstanceId,MachineType,PublicHostname,SecurityGroups'
    options.summary = False
    options.long = False
    options.output = ""
    options.states = ""

    print("The following nodes matched your filter in cluster %s:" % cluster_name)
    _show_nodes(config, options, None)
    force = cyclecli.prompt('Do you wish to %s these instances? [y/N]' % method)

    return force.lower() == 'y'


def _remove_node(config, cluster_name, node_name, options):
    s = cyclecli.get_session(config)

    params = {}
    filters = []

    if options.creds:
        filters.append('Credentials==="%s"' % options.creds)
    if options.filter:
        filters.append(options.filter)
    if options.instance_filter:
        filters.append("InstanceId isnt undefined")
        params['instance-filter'] = options.instance_filter
    if options.force:
        params['force'] = 'true'

    filter_expr = ' && '.join(filters)
    if filter_expr:
        logger.debug("Terminating nodes matching: %s" % filter_expr)
        params['filter'] = filter_expr

    params["remove"] = True

    if not options.noprompt and not node_name:
        if _prompt_for_filter_confirmation(config, options, cluster_name, method='remove') == False:
            return False

    if node_name:
        url = "%s/cloud/actions/terminate_node/%s/%s" % (config["url"], urlquote(cluster_name), urlquote(node_name))
    else:
        url = "%s/cloud/actions/terminate_node/%s" % (config["url"], urlquote(cluster_name))

    r = cyclecloud.util.post(s, url, params=params)
    raise_if_needed(r)

    return True


def _terminate_node(config, cluster_name, node_name, options):
    s = cyclecli.get_session(config)

    filters = []
    params = {}

    if options.creds:
        filters.append('Credentials==="%s"' % options.creds)
    if options.filter:
        filters.append(options.filter)
    if options.instance_filter:
        filters.append("InstanceId isnt undefined")
        params['instance-filter'] = options.instance_filter

    filter_expr = ' && '.join(filters)
    if filter_expr:
        logger.debug("Terminating nodes matching: %s" % filter_expr)
        params['filter'] = filter_expr

    if not options.noprompt and not node_name:
        if _prompt_for_filter_confirmation(config, options, cluster_name, method='terminate') is False:
            return False

    if node_name:
        url = "%s/cloud/actions/terminate_node/%s/%s" % (config["url"], urlquote(cluster_name), urlquote(node_name))
    else:
        url = "%s/cloud/actions/terminate_node/%s" % (config["url"], urlquote(cluster_name))

    r = cyclecloud.util.post(s, url, params=params)
    raise_if_needed(r)

    return True


def _deallocate_node(config, cluster_name, node_name, options):
    s = cyclecli.get_session(config)

    filters = []
    management_req = {"clusterName": cluster_name}

    if options.creds:
        filters.append('Credentials==="%s"' % options.creds)
    if options.filter:
        filters.append(options.filter)

    filter_expr = ' && '.join(filters)
    if filter_expr:
        logger.debug("Deallocating nodes matching: %s" % filter_expr)
        management_req['filter'] = filter_expr

    if not options.noprompt and not node_name:
        if _prompt_for_filter_confirmation(config, options, cluster_name, method='deallocate') is False:
            return False

    if node_name:
        management_req["names"] = [node_name]
    
    r = s.post("%s/clusters/%s/nodes/deallocate" % (config["url"], urlquote(cluster_name)),
        data=json.dumps(management_req))
    r.raise_for_status()

    results = json.loads(r.text)
    if len(results) and results["nodes"]:
        for node_result in results["nodes"]:
            status = node_result.get("status") or "ok"
            if status and status.lower() == "error":
                raise UserError(node_result.get("error"))
            elif status and status.lower() == "ok" and node_result.get("name"):
                print("Deallocated node %s" % node_result.get("name"))

    return True


def _show_nodes(config, options, node_name=None):

    params = {}
    if options.cluster:
        params['cluster'] = options.cluster

    if options.summary:
        params['summary'] = True
    elif options.long:
        params['long'] = True

    if options.format:
        params['format'] = options.format
    elif options.summary:
        params['format'] = 'tabular'
    else:
        params['format'] = 'text'

    if options.attrs:
        params['attrs'] = options.attrs

    if options.output:
        params['output'] = options.output
        if options.attrs:
            print("Both --attrs and --output are specified.  The --attrs option will be dropped.", file=sys.stderr)

    filters = []
    if options.states:
        states = options.states.split(',')
        state_filter = 'State in {%s}' % ','.join(['"%s"' % s.strip() for s in states])
        filters.append(state_filter)

    if options.creds:
        filters.append('Credentials==="%s"' % options.creds)
    if options.filter:
        filters.append(options.filter)
    if options.instance_filter:
        filters.append("InstanceId isnt undefined")
        params['instance-filter'] = options.instance_filter

    filter_expr = ' && '.join(filters)
    if filter_expr:
        logger.debug("Terminating nodes matching: %s" % filter_expr)
        params['filter'] = filter_expr

    s = cyclecli.get_session(config)

    # TODO: change to /cloud/api/nodes
    url = "/cloud/nodes/%s" % node_name if node_name else "/cloud/nodes"
    r = cyclecloud.util.get(s, config["url"] + url, params=params)
    raise_if_needed(r)

    print(r.text)


def _connect(config, given_name, options):
    s = cyclecli.get_session(config)

    policy_params = {}

    # indicates to the server that it should resolve this as either a node name, hostname, or IP address, if one matches.
    # note that older CycleCloud installs will not recognize this, but they will continue to use the filter we also set.
    policy_params["NameToResolve"] = '"%s"' % given_name

    # we get all of the connection info from the datasource
    query_filter = 'Name == "%s"' % given_name
    params = {}
    if hasattr(options, "cluster") and options.cluster:
        params["cluster"] = options.cluster
        query_filter += ' && ClusterName == "%s"' % options.cluster
        policy_params["ClusterName"] = '"%s"' % options.cluster

    if hasattr(options, "keyfile"):
        params["keyfile"] = options.keyfile

    if hasattr(options, "user") and options.user:
        policy_params["User"] = '"%s"' % options.user

    bastion_host = None
    bastion_ssh_port = None
    bastion_user = None
    bastion_keyfile = None
    bastion_fingerprint = None
    bastion_preferred_key_name = None
    bastion_auto_detect = True

    if "bastion_auto_detect" in config["cyclecloud"]:
        bastion_auto_detect = config["cyclecloud"]["bastion_auto_detect"]

    if hasattr(options, "bastion-host") and getattr(options, "bastion-host"):
        bastion_host = getattr(options, "bastion-host")
    elif "bastion_host" in config["cyclecloud"]:
        bastion_host = config["cyclecloud"]["bastion_host"]

    if bastion_auto_detect:
        policy_params["BastionAutoDetect"] = "true"

    # Serialize policy params
    if policy_params.keys:
        policy_str = ""
        for k, v in policy_params.items():
            policy_str = policy_str + "%s=%s;" % (k, v)
        params["policyexpr_Parameters"] = "[%s]" % policy_str

    params["include_password"] = "true"
    query = 'select * using cloud.node.ui.connect_datasource where %s' % query_filter
    url = "%s/exec/query/?q=%s&format=json" % (config["url"], urlquote(query))
    r = cyclecloud.util.get(s, url, params=params)
    raise_if_needed(r)

    results = json.loads(r.text)
    if not results:
        print("Unable to determine connect info for node/hostname/IP address: %s" % given_name)
        return
    result = CaseInsensitiveDict(results[0])

    if "ConnectError" in result:
        print(result["ConnectError"])
        return

    operating_system = result.get("OperatingSystem")
    clustername = result.get("ClusterName")
    nodename = result.get("Name")
    hostname = result.get("Host")
    username = options.user or result.get("Username")
    pw = result.get("Password")
    instance_id = result.get("InstanceId")
    remote_keypair_location = result.get("KeyPairLocation")
    fingerprint = result.get("KeyPairFingerprint")
    bastion = result.get("SSHBastion")

    autodetected_bastion_host = None
    if bastion and bastion.get("Host"):
        autodetected_bastion_host = bastion.get("Host")

    use_autodetected_bastion_info = False
    if not bastion_host and autodetected_bastion_host:
        use_autodetected_bastion_info = True
        bastion_host = autodetected_bastion_host

    if bastion_host:
        if hasattr(options, "bastion-port") and getattr(options, "bastion-port"):
            bastion_ssh_port = getattr(options, "bastion-port")
        elif "bastion_port" in config["cyclecloud"]:
            bastion_ssh_port = config["cyclecloud"]["bastion_port"]
        
        if hasattr(options, "bastion-user") and getattr(options, "bastion-user"):
            bastion_user = getattr(options, "bastion-user")
        elif "bastion_user" in config["cyclecloud"]:
            bastion_user = config["cyclecloud"]["bastion_user"]
        
        if hasattr(options, "bastion-key") and getattr(options, "bastion-key"):
            bastion_keyfile = getattr(options, "bastion-key")
        elif "bastion_key" in config["cyclecloud"]:
            bastion_keyfile = config["cyclecloud"]["bastion_key"]

    if not hostname:
        print("No hostname or ip address found for instance %s; the instance may not be ready yet" % instance_id)
        return

    if use_autodetected_bastion_info:
        bastion_fingerprint = bastion.get("KeyPairFingerprint")
        # Don't override user-specified port or user name
        if not bastion_user:
            bastion_user = bastion.get("Username")
        if not bastion_ssh_port:
            bastion_ssh_port = bastion.get("Port")

        bastion_keypair_location = bastion.get("KeyPairLocation")

        # Set the preferred key name to be the same as the bastion node's 
        # keypair file name
        bastion_preferred_key_name = None
        if bastion_keypair_location is not None:
            bastion_preferred_key_name = os.path.basename(bastion_keypair_location)

    if operating_system == "windows":
        rdp_port = None
        if "Port" in result:
            rdp_port = result.get("Port")

        command_template = None
        if "rdp_command" in config["cyclecloud"]:
            # User-specified RDP command template
            command_template = config["cyclecloud"]["rdp_command"]

        rdp_to_instance(clustername, nodename, hostname, username, pw, 
            rdp_port=rdp_port, command_template=command_template, 
            bastion_host=bastion_host, bastion_ssh_port=bastion_ssh_port,
            bastion_user=bastion_user, bastion_keyfile=bastion_keyfile,
            bastion_fingerprint=bastion_fingerprint,
            bastion_preferred_key_name=bastion_preferred_key_name)
    else:
        ssh_port = None
        if "Port" in result:
            ssh_port = result.get("Port")

        keyfile = None
        if hasattr(options, "keyfile") and options.keyfile is not None:
            keyfile = options.keyfile

        # Set the preferred key name to be the same as the server's keypair
        # file name
        preferred_key_name = None
        if remote_keypair_location is not None:
            preferred_key_name = os.path.basename(remote_keypair_location)

        ssh_to_instance(clustername, nodename, hostname, username, ssh_port=ssh_port, 
            keyfile=keyfile, fingerprint=fingerprint, 
            preferred_key_name=preferred_key_name,
            bastion_host=bastion_host, bastion_ssh_port=bastion_ssh_port,
            bastion_user=bastion_user, bastion_keyfile=bastion_keyfile,
            bastion_fingerprint=bastion_fingerprint,
            bastion_preferred_key_name=bastion_preferred_key_name)


def _display_cluster_message(text, cluster, recursive):
    print(_get_cluster_message(text, cluster, recursive))


def _get_cluster_message(text, cluster, recursive):
    display_name = cluster
    if recursive:
        display_name = "%s and its child clusters" % cluster
    return "%s %s...." % (text, display_name)


def _extract_parameters(options):
    if not options.parameter_overrides:
        return options.parameters
    
    if options.parameters:
        params_file = os.path.expanduser(options.parameters)
        if not os.path.exists(params_file):
            raise ValueError("File %s not found" % params_file)
        
        try:
            with open(params_file) as fr:
                parameters = json.load(fr)
        except ValueError as e:
            raise ValueError("When using -P/--parameter-override the -p/--parameter file format must be valid json. - %s" % str(e))

    
    else:
    
        parameters = {}
    
    for expr in options.parameter_overrides:

        if "=" not in expr:
            raise ValueError("for -P/--parameter-override '%s', expected key=value." % (expr))
        
        key, value = expr.split("=", 1)
        if value.startswith("@"):
            path = value[1:]
            if not os.path.exists(path) or not os.path.isfile(path):
                raise ValueError("%s does not exist. Specified as -P %s=@%s" % (path, key, path))

            with open(path) as fr:
                value = fr.read()
        elif value.lower() in ["true", "false"]:
            value = value.lower() == "true"
        else:
            for converter in [int, float, str]:
                try:
                    value = converter(value)
                    break
                except ValueError:
                    pass

        parameters[key.strip()] = value
    
    logger.info("Returning parameters - %s" % parameters)
    return parameters

class ShowClusterCommand(BaseCommand):

    def __init__(self):
        self.args = "CLUSTER"
        self.description = "Shows the cluster or clusters in CycleCloud."

    def configure(self, parser):
        parser.add_option("-r", '--recursive', dest='recursive', help="Show this cluster and all of its sub-clusters.",
                          action="store_true")
        parser.add_option("-l", '--long', dest='long', help="Lists each node rather than showing a summary.",
                          action="store_true")
        parser.add_option("-t", "--templates", dest='templates', help="Include cluster templates in the output.", action="store_true")

    def execute(self, options, arguments):
        config = cyclecli.get_config()
        if len(arguments) != 1:
            _listclusters(config, options)
        else:
            name = arguments[0]
            _showcluster(config, name, options)


class StartClusterCommand(BaseCommand):

    def __init__(self):
        self.args = "CLUSTER"
        self.description = "Starts the named cluster."

    def configure(self, parser):
        parser.add_option("-r", "--recursive", dest="recursive",
                          help="Recursively start this cluster and all its sub-clusters.",
                          action="store_true")
        parser.add_option("-t", "--test", dest="test_mode",
                          help="Start cluster in test mode",
                          action="store_true")

    def execute(self, options, arguments):
        if len(arguments) != 1:
            raise ArgumentError("Cluster name is required")

        config = cyclecli.get_config()
        name = arguments[0]
        _startcluster(config, name, options)

        _display_cluster_message("Starting cluster", name, options.recursive)

        _showcluster(config, name, options)


class TerminateClusterCommand(BaseCommand):

    def __init__(self):
        self.args = "CLUSTER"
        self.description = "Terminates the named cluster."

    def configure(self, parser):
        parser.add_option("-r", "--recursive", dest="recursive", action="store_true",
                          help="Recursively terminate this cluster and all its sub-clusters.")

    def execute(self, options, arguments):
        if len(arguments) != 1:
            raise ArgumentError("Cluster name is required")

        config = cyclecli.get_config()
        name = arguments[0]
        _terminate(config, name, options)
        _display_cluster_message("Terminating cluster", name, options.recursive)
        _showcluster(config, name, options)


class DeleteClusterCommand(BaseCommand):
    def __init__(self):
        self.args = "CLUSTER"
        self.description = "Deletes a non-running cluster."

    def configure(self, parser):
        parser.add_option("-r", "--recursive", dest="recursive", action="store_true",
                          help="Recursively delete this cluster and all its sub-clusters.")
        parser.add_option("--force", dest="force", action="store_true",
                          help="Force this cluster to be deleted. Note: only use this option if all resources in your cloud provider are already terminated!")

    def execute(self, options, arguments):
        if len(arguments) != 1:
            raise ArgumentError("Cluster name is required")

        config = cyclecli.get_config()
        name = arguments[0]
        _deletecluster(config, name, options)
        message = "Deleting cluster"
        if options.force:
            message = "Forcibly deleting cluster"
        message = _get_cluster_message(message, name, options.recursive)
        if options.force:
            message += " Warning: instances may be left running in the cloud!"
        print(message)
        # this currently doesn't have a wait option
        time.sleep(1)

class DeleteTemplateCommand(BaseCommand):
    def __init__(self):
        self.args = "TEMPLATE"
        self.description = "Deletes a cluster template"
    
    def execute(self, options, arguments):
        if len(arguments) != 1:
            raise ArgumentError("Template name is required")
        
        name = arguments[0]

        config = cyclecli.get_config()

        cyclecloud.api.delete_cluster(config, name, recursive=False, force=False, template=True)
        message = "Deleting template"
        message = _get_cluster_message(message, name, False)
        print(message)

        time.sleep(1)


class ImportTemplateCommand(BaseCommand):
    """ Imports a CycleCloud cluster template """
    def __init__(self):
        self.args = "[NAME]"
        self.description = "Imports a cluster template from a text file. If NAME is not given, and the file has a single cluster, the name of that cluster is used."

    def configure(self, parser):
        parser.add_option("-c", 
                          dest="template", 
                          help="The template in the file to import. If not specified, the name of the new template is used.")
        parser.add_option('--force', 
                          dest="force", 
                          action="store_true", 
                          help="If specified, the template will be replaced if it exists")
        parser.add_option("-f", "--file", dest="file",
                          help="The file from which to import the template.",
                          metavar="FILE",
                          default="")

    def execute(self, options, arguments):
        name = None
        if len(arguments) >= 1:
            name = arguments[0]

        config = cyclecli.get_config()

        if options.file == "":
            raise ArgumentError("File to import from (-f FILE, --file=FILE) is required")

        source = options.template or name

        if source is not None:
            print("Importing template %s...." % source)
        else:
            print("Importing default template in %s...." % (options.file))
            
        new_name = cyclecloud.api.import_cluster(config, name, options.template, as_template=True, config_file=options.file, force=options.force)
        if new_name is not None:
            name = new_name

        _showcluster(config, name, options)
        
        
class CreateClusterCommand(BaseCommand):
    """ Creates a cluster from a template """
    def __init__(self):
        self.args = "TEMPLATE NAME"
        self.description = "Creates a cluster from an existing template."

    def configure(self, parser):
        parser.add_option('--force',
                          dest='force',
                          action='store_true',
                          help="If specified, the cluster will be replaced if it exists")
        parser.add_option("-p", "--parameters", dest="parameters",
                          help="The parameters file to use",
                          metavar="PARAMETERS",
                          default="")
        parser.add_option("-P", "--parameter-override", dest="parameter_overrides",
                          help="Add or override a specific parameter. Takes precedent over values specified in -p.",
                          metavar="PARAMETER_OVERRIDE",
                          action="append",
                          default=[])

    def execute(self, options, arguments):
        if len(arguments) != 2:
            raise ArgumentError("Template name and cluster name are required")
        
        config = cyclecli.get_config()
        template = arguments[0]
        name = arguments[1]

        cyclecloud.api.import_cluster(config, name, template, force=options.force, parameters=_extract_parameters(options))
        _showcluster(config, name, options)

        
class ImportClusterCommand(BaseCommand):

    def __init__(self):
        self.args = "[CLUSTER]"
        self.description = "Creates a cluster from a text file. If CLUSTER is not given, and the file has a single cluster, the name of that cluster is used."

    def configure(self, parser):
        parser.add_option("-c", dest="template",
                          help="The cluster in the file to import. If not specified, the name of the new cluster is used.")
        parser.add_option("--force", dest="force", action="store_true",
                          help="If specified, the cluster will be replaced if it exists.")
        parser.add_option("-t", "--as-template", dest="as_template", action="store_true",
                          help="If specified, the cluster is stored as a template which can only be used to create other clusters.")
        parser.add_option("-f", "--file", dest="file",
                          help="The file from which to import the template.",
                          metavar="FILE",
                          default="")
        parser.add_option("-p", "--parameters", dest="parameters",
                          help="The parameters file to use",
                          metavar="PARAMETERS",
                          default="")
        parser.add_option("-P", "--parameter-override", dest="parameter_overrides",
                          help="Add or override a specific parameter. Takes precedent over values specified in -p.",
                          metavar="PARAMETER_OVERRIDE",
                          action="append",
                          default=[])
        parser.add_option("-r", "--recursive", dest="recursive", action="store_true",
                          help="Imports the named cluster and all clusters in the file for which it is the parent.")

    def execute(self, options, arguments):
        name = None
        if len(arguments) >= 1:
            name = arguments[0]

        config = cyclecli.get_config()

        if options.file == "":
            raise ArgumentError("File to import from (-f FILE, --file=FILE) is required")

        source = options.template or name
        template_type = ""
        if options.as_template:
            template_type = " as a template"

        if source is not None:
            print("Importing cluster %s and creating cluster %s%s...." % (source, name, template_type))
        else:
            print("Importing default cluster%s from %s...." % (template_type, options.file))
            
        new_name = cyclecloud.api.import_cluster(config, name, options.template, config_file=options.file, force=options.force, 
                                                 as_template=options.as_template, recursive=options.recursive,parameters=_extract_parameters(options))

        if new_name is not None:
            name = new_name
            
        _showcluster(config, name, options)


class RetryClusterCommand(BaseCommand):

    def __init__(self):
        self.args = "CLUSTER"
        self.description = "Retries failed initialization operations for the named cluster."

    def configure(self, parser):
        parser.add_option("-r", "--recursive", dest="recursive", action="store_true",
                          help="Recursively retry options in this cluster and all its sub-clusters.")

    def execute(self, options, arguments):
        if len(arguments) != 1:
            raise ArgumentError("Cluster name is required")

        config = cyclecli.get_config()
        name = arguments[0]
        _display_cluster_message("Retrying failed operations for cluster", name, options.recursive)

        _retrycluster(config, name, options)

        _showcluster(config, name, options)


class AddNodeCommand(BaseCommand):

    def __init__(self):
        self.args = "CLUSTER"
        self.description = "Adds more nodes to the cluster."
        self.aliases = ['add_nodes']

    def configure(self, parser):
        parser.add_option("-t", "--template", dest="template",
                          help="The template to use for this node. If not specified, the default is to use the only template available otherwise error.")
        parser.add_option("-c", "--count", dest="count",
                          help="How many nodes to start. If not specified, the default is 1.")
        parser.add_option("-f", "--fixed", dest="fixed", action="store_true",
                          help="If set, node will be added permanently (until removed) to the cluster template.  Otherwise node will be removed automatically when terminated.")

    def execute(self, options, arguments):
        if len(arguments) != 1:
            raise ArgumentError("Cluster name is required")

        config = cyclecli.get_config()
        name = arguments[0]
        print("Adding nodes to cluster %s...." % name)
        _add_nodes(config, name, options)

        _showcluster(config, name, options)


class StartNodeCommand(BaseCommand):

    def __init__(self):
        self.args = "CLUSTER NODE_NAME"
        self.description = "(Re-)Starts terminated nodes in a running cluster."

    def configure(self, parser):
        pass

    def execute(self, options, arguments):
        if len(arguments) < 1:
            raise ArgumentError("Cluster name and node name are required")
        if len(arguments) < 2:
            raise ArgumentError("Node name is required")

        config = cyclecli.get_config()
        cluster_name = arguments[0]
        node_name = None
        node_name = arguments[1]
        print("Starting node %s in cluster %s..." % (node_name, cluster_name))

        _start_nodes(config, cluster_name, node_name, options)

        _showcluster(config, cluster_name, options)


class RebootNodeCommand(BaseCommand):

    def __init__(self):
        self.args = "CLUSTER NODE_NAME"
        self.description = "Reboot a running node."

    def configure(self, parser):
        pass

    def execute(self, options, arguments):
        if len(arguments) < 1:
            raise ArgumentError("Cluster name and node name are required")
        if len(arguments) < 2:
            raise ArgumentError("Node name is required")

        config = cyclecli.get_config()
        cluster_name = arguments[0]
        node_name = None
        node_name = arguments[1]
        print("Rebooting node %s in cluster %s..." % (node_name, cluster_name))

        _reboot_nodes(config, cluster_name, node_name, options)

        # this currently doesn't have a proper wait component
        time.sleep(1)
        _showcluster(config, cluster_name, options)


class RemoveNodeCommand(BaseCommand):

    def __init__(self):
        self.args = "CLUSTER NODE_NAME"
        self.description = "Removes a node from the cluster (and terminates it if started)."
        self.aliases = ['remove_nodes']

    def configure(self, parser):
        parser.add_option("-f", "--filter", dest="filter",
                          help="Remove nodes matching the complete class-ad expression.")
        parser.add_option("--instance-filter", dest="instance_filter",
                          help="Remove nodes with active instances matching the complete class-ad expression.")
        parser.add_option("--creds", dest="creds",
                          help="Remove nodes started using the named set of credentials.")
        parser.add_option('--no-prompt', dest='noprompt', action="store_true",
                          help="If specified, will not ask for confirmation before terminating nodes based on a filter.")
        parser.add_option("--force", dest="force", action="store_true",
                          help="Force this node to be removed, even if not terminated. " +
                          "Note: only use this option if the resources for this node in your cloud provider are already terminated!")

    def execute(self, options, arguments):
        if len(arguments) not in [1, 2]:
            raise ArgumentError("Cluster name and node name are required")

        config = cyclecli.get_config()
        cluster_name = arguments[0]
        if len(arguments) == 2:
            node_name = arguments[1]
            message = " node %s in cluster %s" % (node_name, cluster_name)
            if options.force:
                message = "Forcibly removing" + message
            else:
                message = "Removing" + message

            if options.force:
                message += " Warning: instances may be left running in the cloud!"
            else:
                message += "...."
            print(message)
        else:
            node_name = None

        show_cluster = _remove_node(config, cluster_name, node_name, options)

        if show_cluster:
            _showcluster(config, cluster_name, options)


class TerminateNodeCommand(BaseCommand):

    def __init__(self):
        self.args = "CLUSTER NODE_NAME"
        self.description = "Terminates a running node (but leaves it in the cluster)."
        self.aliases = ['terminate_nodes']

    def configure(self, parser):
        parser.add_option("-f", "--filter", dest="filter",
                          help="Terminate nodes matching the complete class-ad expression.")
        parser.add_option("--instance-filter", dest="instance_filter",
                          help="Terminate nodes with active instances matching the complete class-ad expression.")
        parser.add_option("--creds", dest="creds",
                          help="Terminate nodes started using the named set of credentials.")
        parser.add_option('--no-prompt', dest='noprompt', action="store_true",
                          help="If specified, will not ask for confirmation before terminating nodes based on a filter.")

    def execute(self, options, arguments):
        if len(arguments) not in [1, 2]:
            raise ArgumentError("Cluster name and/or node name are required")

        config = cyclecli.get_config()
        cluster_name = arguments[0]
        if len(arguments) == 2:
            node_name = arguments[1]
            print("Terminating node %s in cluster %s...." % (node_name, cluster_name))
        else:
            node_name = None

        show_cluster = _terminate_node(config, cluster_name, node_name, options)

        if show_cluster:
            _showcluster(config, cluster_name, options)


class DeallocateNodeCommand(BaseCommand):

    def __init__(self):
        self.args = "CLUSTER NODE_NAME"
        self.description = "Deallocates a running node."
        self.aliases = []

    def configure(self, parser):
        parser.add_option("-f", "--filter", dest="filter",
                          help="Deallocate nodes matching the complete class-ad expression.")
        parser.add_option("--creds", dest="creds",
                          help="Deallocate nodes started using the named set of credentials.")
        parser.add_option('--no-prompt', dest='noprompt', action="store_true",
                          help="If specified, will not ask for confirmation before deallocating nodes based on a filter.")

    def execute(self, options, arguments):
        if len(arguments) not in [1, 2]:
            raise ArgumentError("Cluster name and/or node name are required")

        config = cyclecli.get_config()
        cluster_name = arguments[0]
        if len(arguments) == 2:
            node_name = arguments[1]
            print("Deallocating node %s in cluster %s...." % (node_name, cluster_name))
        else:
            node_name = None

        show_cluster = _deallocate_node(config, cluster_name, node_name, options)

        if show_cluster:
            _showcluster(config, cluster_name, options)


class ShowNodesCommand(BaseCommand):
    '''Describe a set of nodes matching the specified criteria.
    '''

    def __init__(self):
        self.args = " [NAME]"
        self.description = "Show details of selected nodes/instances."
        self.aliases = ['show_node']

    def configure(self, parser):
        parser.add_option("-a", "--attrs", dest="attrs",
                          help="Display the specified set of attributes (comma-separated list).")
        parser.add_option("-f", "--filter", dest="filter",
                          help="Show only nodes matching the complete class-ad expression.")
        parser.add_option("--instance-filter", dest="instance_filter",
                          help="Show only nodes with active instances matching the complete class-ad expression.")
        parser.add_option("--output", dest="output",
                          help="Output the matching node attributes described by a Python-style named-parameter format string.  Ex. --output=\"Name: %(Name)s\\t(ID: %(InstanceId)s)\\n Cluster: %(ClusterName)s\\n\"")
        parser.add_option("--format", dest="format",
                          help="Change the output display format [xml | json | text].")
        parser.add_option("--creds", dest="creds",
                          help="Show only nodes started using the named set of credentials.")
        parser.add_option("-c", "--cluster", dest="cluster",
                          help="Show only nodes in the specified cluster.")
        parser.add_option("--states", dest="states",
                          help="Show only nodes in the specified states (comma-separated list).")
        parser.add_option("-l", "--long", dest="long", action="store_true",
                          help="Display the complete class-ad representation of the node.")
        parser.add_option("-s", "--summary", dest="summary", action="store_true",
                          help="Display a minimal representation of the node.")

    def execute(self, options, arguments):

        config = cyclecli.get_config()
        node_name = arguments[0] if arguments else None
        _show_nodes(config, options, node_name)


class ConnectCommand(BaseCommand):

    def __init__(self):
        self.args = "NAME"
        self.description = "Connects to a running instance in the cluster. As of 7.8, the Name can be either a node name, a hostname, or an IP address."

    def configure(self, parser):
        parser.add_option("-k", "--keyfile", dest="keyfile",
                          help="The keypair to use, if not given on the node or the node does not exist.")
        parser.add_option("-c", "--cluster", dest="cluster",
                          help="The cluster the node is in, if the name is a node name. Optional unless there are multiple nodes with the same name.")
        parser.add_option("-u", "--user", dest="user",
                          help="The user to login to the node with.")
        parser.add_option("--bastion-host", dest="bastion-host",
                          help="SSH bastion host to route connections through.")
        parser.add_option("--bastion-port", dest="bastion-port",
                          help="SSH port for connecting to the bastion.")
        parser.add_option("--bastion-user", dest="bastion-user",
                          help="User login for connecting to the bastion.")
        parser.add_option("--bastion-key", dest="bastion-key",
                          help="Private key file for connecting to the bastion.")

    def execute(self, options, arguments):
        if len(arguments) != 1:
            raise ArgumentError("Node name is required")

        config = cyclecli.get_config()
        given_name = arguments[0]
        _connect(config, given_name, options)


class InitializeCommand(BaseCommand):

    def __init__(self):
        self.args = ""
        self.description = "Initializes CycleCloud settings."

    def configure(self, parser):
        cyclecli.configure_initialize(parser)

    def execute(self, options, arguments):
        cyclecli.initialize(application_name=_application_name, options=options,
                            force_reconfig=options.force, named_config=options.named_config)
        _initialize_templates()


class OutputImagesCommand(BaseCommand):

    def __init__(self):
        self.args = "CLUSTER"
        self.description = "Writes out the image/package information"

    def configure(self, parser):
        parser.add_option("--cyclecloud", dest="cyclecloud",
                          help="The path to the CycleCloud git repo")

    def execute(self, options, arguments):
        if len(arguments) != 1:
            raise ArgumentError("Cluster name is required")

        config = cyclecli.get_config()
        name = arguments[0]
        ds = cyclecli.get_datastore(config)
        params = ds.find("Cloud.ClusterParameter", 'ClusterName == "%s" && Name == "%s"' % (name, "Version"))
        if len(params) == 0:
            raise UserError("Cannot find version in cluster %s" % name)

        version = params[0]["Value"]
        artifacts = ds.find("Artifact", 'Version == "%s"' % version)

        packages = ds.find("Package", 'Version == "%s" && PackageType == "image" && Cycle' % version)

        package_names = [package["Name"] for package in packages]

        quoted_package_names = ['"%s"' % package_name for package_name in package_names]
        artifacts = ds.find("Artifact", 'Package in {%s} && Version == "%s"' % (", ".join(quoted_package_names), version))

        # output overall release
        package_map = {}
        
        # KLUDGE!
        package_map["cycle.cookbooks.common"] = version

        for p in packages:
            package_map[p["Name"]] = p["Version"]

        release_package = {"AdType": "Package", "Name": "cycle.release", "Version": version}
        release_package["Manifest"] = package_map
        release_package["PackageType"] = "bundle"

        if options.cyclecloud:
            path = os.path.join(os.path.expanduser(options.cyclecloud), "src/main/component/plugins")

            if not os.path.exists(path):
                raise UserError("%s does not appear to be a valid CycleCloud repository" % options.cyclecloud)

            # output image packages
            self._output_records(packages, os.path.join(path, "cloud/initial_data/static"), "image_packages_%s.json" % version)
        
            # output artifacts
            artifact_map = {}
            for artifact in artifacts:
                provider = artifact["Provider"]
                artifact_list = artifact_map.get(provider, [])
                artifact_map[provider] = artifact_list
                artifact_list.append(artifact)
            
            self._output_records([release_package], os.path.join(path, "cloud/initial_data/static"), "release_package_%s.json" % version)                
                                        
    def _output_records(self, items, path, name):
        if not os.path.exists(path):
            os.makedirs(path)

        l = []
        for i in items:
            d = {}
            for k, v in i.items():
                if type(v) == cyclecli.datastore.CaseInsensitiveDict:
                    v = dict(v)
                d[k] = v
            l.append(d)

        l.sort(key=lambda x: x["Name"] + "/" + (x.get("Package") or ""))

        with open(os.path.join(path, name), "w") as f:
            json.dump(l, f, sort_keys=True, indent=4)


class ImportProjectCommand(BaseCommand):
    def __init__(self):
        self.args = "REPOSITORY URL"
        self.description = "Imports a project into the CycleCloud codebase from a given Github URL"

    def configure(self, parser):
        parser.add_option("-t", "--template", dest='template', help="Use cluster template for importing project.")

    def execute(self, options, arguments):
        if len(arguments) != 2:
            raise ArgumentError("Repository path and URL are required")

        repository = arguments[0]
        url = arguments[1]

        cyclecloud.api.import_project(repository, url, options.template)
                                                                                                                                                        
class AwaitTargetStateCommand(BaseCommand):

    def __init__(self):
        self.args = "NAME"
        self.description = "Blocks until a cluster or node has reached its destination state or until an optional timeout (3 hr default)."

    def configure(self, parser):
        parser.add_option("-n", "--node", dest="node",
                          help="A specific node to wait on instead of the entire cluster.")
        parser.add_option("-t", "--timeout", dest="timeout",
                          help="The maximum number of seconds to wait before timing out and failing.")

    def execute(self, options, arguments):
        if len(arguments) != 1:
            raise ArgumentError("Cluster name is required")

        config = cyclecli.get_config()
        name = arguments[0]
        return self._await_state(config, name, options)

    def _await_state(self, config, name, options):
        s = cyclecli.get_session(config)

        single_node = False

        params = {}
        if hasattr(options, "node") and options.node is not None:
            params["cluster"] = name
            params["require_instance"] = False
            url = "%s/cloud/node/%s" % (config["url"], urlquote(options.node))
            single_node = True
        else:
            # TODO: change to /cloud/api/clusters
            url = "%s/cloud/clusters/%s" % (config["url"], urlquote(name))

        timeout = time.time() + (60 * 60 * 3)  # 3 hour default
        if hasattr(options, "timeout") and options.timeout is not None:
            timeout = time.time() + int(options.timeout)

        next_check = time.time()

        if single_node:
            print("Waiting for '%s' to reach target state..." % options.node)
        else:
            print("Waiting for '%s' to reach target state..." % name)

        while True:
            if(next_check < time.time()):
                next_check = time.time() + 15

                r = cyclecloud.util.get(s, url, params=params)
                raise_if_needed(r)

                result = json.loads(r.text)
                if not single_node:
                    result = result[0]
                result = CaseInsensitiveDict(result)

                if single_node:
                    nodedata = CaseInsensitiveDict(result["node"])
                    if nodedata["targetstate"] == nodedata["state"]:
                        break

                    if "phasefailed" in nodedata and nodedata["phasefailed"] is True:
                        raise UserError("Node failed phase, will never reach target state...")

                else:
                    if result["targetstate"] == result["state"]:
                        break

            if timeout < time.time():
                raise UserError("Timeout waiting for '%s' to reach target state." % name)

            time.sleep(1)


def _initialize_templates():
    """ Write our default templates to ~/.cycle/ if they don't already exist """
    import glob

    if hasattr(sys, "_MEIPASS"):
        template_files = glob.glob(os.path.join(sys._MEIPASS, "templates", "*.txt"))
    else:
        template_files = glob.glob(os.path.join(os.path.dirname(__file__), "templates", "*.txt"))

    for template in template_files:
        filename = os.path.basename(template)
        if not os.path.isfile(os.path.expanduser(os.path.join("~/.cycle", filename))):
            f = open(template, "r")
            content = f.read()
            f.close()
            f = open(os.path.expanduser(os.path.join("~/.cycle", filename)), "w")
            f.write(content)
            f.close()
            print("Wrote cluster template file '%s'." % os.path.join("~/.cycle", filename))


class CycleCloudConfigSection(ConfigSection):
    def __init__(self):
        super(CycleCloudConfigSection, self).__init__("cyclecloud", section_required=False)

    def read(self, parser):
        if parser.has_option(self.name, "rdp_command"):
            # user specified
            self.config["rdp_command"] = parser.get(self.name, "rdp_command")

        if parser.has_option(self.name, "ssh_port"):
            # override default ssh port
            self.config["ssh_port"] = parser.get(self.name, "ssh_port")

        if parser.has_option(self.name, "bastion_auto_detect"):
            self.config["bastion_auto_detect"] = parser.getboolean(self.name, "bastion_auto_detect")

        if parser.has_option(self.name, "bastion_host"):
            self.config["bastion_host"] = parser.get(self.name, "bastion_host")

        if parser.has_option(self.name, "bastion_port"):
            self.config["bastion_port"] = parser.get(self.name, "bastion_port")

        if parser.has_option(self.name, "bastion_user"):
            self.config["bastion_user"] = parser.get(self.name, "bastion_user")

        if parser.has_option(self.name, "bastion_key"):
            self.config["bastion_key"] = parser.get(self.name, "bastion_key")

        return self.config

    def config_batch(self, parser, config, options):
        if not parser.has_section(self.name):
            parser.add_section(self.name)

        self._initialize_cloud(config, options)

    def config_wizard(self, parser, config):
        if not parser.has_section(self.name):
            parser.add_section(self.name)

        # prompt user for input to build rdp_command--this probably won't ever be part of the wizard
        # parser.set(self.name, 'rdp_command', rdp_command)

        self._initialize_cloud(config, None)

    def _get_option(self, options, name, default=None):
        value = getattr(options, name)
        if value is None:
            value = default
        return value

    def _get_required_option(self, options, name):
        value = getattr(options, name)
        if not value:
            raise UserError("The %s argument is required." % name)
        return value

    def _initialize_cloud(self, config, options=None):
        ds = cyclecli.get_datastore(config)
        result = ds.find("Cloud.ProviderAccount")

        if len(result) > 0:
            print("Initial account already exists, skipping initial account creation.")
            return

        if not options:
            # Skip this for batch configuration
            account.modify_account(initial_config=config)
            print("Account initialized and new credentials stored.")


def run(args):
    cyclecli.register_config_section(CycleCloudConfigSection())

    cyclecloud_commands = {}
    cyclecloud_commands["show_cluster"] = ShowClusterCommand()
    cyclecloud_commands["start_cluster"] = StartClusterCommand()
    cyclecloud_commands["terminate_cluster"] = TerminateClusterCommand()
    cyclecloud_commands["import_cluster"] = ImportClusterCommand()
    cyclecloud_commands["import_template"] = ImportTemplateCommand()
    cyclecloud_commands["delete_template"] = DeleteTemplateCommand()
    cyclecloud_commands["create_cluster"] = CreateClusterCommand()
    cyclecloud_commands["initialize"] = InitializeCommand()
    cyclecloud_commands["config"] = cyclecli.ConfigCommand(config_file='config.ini',
                                                           application_name=_application_name,
                                                           identifying_section='cycleserver',
                                                           identifying_keyword='url')
    cyclecloud_commands["retry"] = RetryClusterCommand()
    cyclecloud_commands["add_node"] = AddNodeCommand()
    cyclecloud_commands["show_nodes"] = ShowNodesCommand()
    cyclecloud_commands["start_node"] = StartNodeCommand()
    cyclecloud_commands["reboot_node"] = RebootNodeCommand()
    cyclecloud_commands["remove_node"] = RemoveNodeCommand()
    cyclecloud_commands["terminate_node"] = TerminateNodeCommand()
    cyclecloud_commands["deallocate_node"] = DeallocateNodeCommand()
    cyclecloud_commands["delete_cluster"] = DeleteClusterCommand()
    cyclecloud_commands["connect"] = ConnectCommand()

    # HACK: Check to see if "CycleCloudDevel" environment variable is set (to anything)
    # If yes, we include some devel commands. Example:
    #     export CycleCloudDevel=1     <--- set it
    #     unset CycleCloudDevel        <--- unset it
    import os
    if os.getenv('CycleCloudDevel'):
        cyclecloud_commands["output_images"] = OutputImagesCommand()
        cyclecloud_commands["await_target_state"] = AwaitTargetStateCommand()
        cyclecloud_commands["import_project"] = ImportProjectCommand()

    # END HACK

    deprecated = {"showcluster": "show_cluster",
                  "terminate": "terminate_cluster",
                  "import": "import_cluster",
                  "add": "add_node",
                  "delete": "delete_cluster",
                  "listclusters": "show_cluster"}

    cyclecli.register_commands(cyclecloud_commands)
    commands.register_commands(_application_name)
    cyclecli.deprecate_commands(deprecated)

    return cyclecli.run(args, app_name=_application_name, version=__version__)


def main():
    run(sys.argv[1:])

    
if __name__ == "__main__":
    main()
