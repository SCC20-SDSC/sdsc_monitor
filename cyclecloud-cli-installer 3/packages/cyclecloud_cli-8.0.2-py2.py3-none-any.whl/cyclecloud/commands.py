
import copy
import json
import os
import sys

import cyclecli
import cyclecloud
import cyclecloud.account
import cyclecloud.tests
import cyclecloud.util
import projects
from cyclecli import (YES_NO_SET, YES_SET, ArgumentError, BaseCommand,
                      UserError, expressions, records)
from cyclecloud.util import CaseInsensitiveDict
from six.moves import urllib

CASCADE_DELETE_ATTR = "CascadeProviderAccountDeletion"


def urlquote(arg):
    return urllib.parse.quote(arg, safe="")


def register_commands(application_name):
    cyclecloud_commands = {}
    cyclecloud_commands["account"] = AccountCommand(application_name)
    cyclecloud_commands["image"] = ImageCommand(application_name)
    cyclecloud_commands["copy_cluster"] = CopyClusterCommand()
    cyclecloud_commands["export_parameters"] = ExportParametersCommand(application_name)
    cyclecloud_commands["credential"] = CredentialCommand(application_name)
    cyclecloud_commands["project"] = ProjectCommand(application_name)
    cyclecloud_commands["locker"] = LockerCommand(application_name)

    cyclecli.register_commands(cyclecloud_commands)


def _get_optional(p, section, name, default=None):
    value = default
    if p.has_option(section, name):
        value = p.get(section, name)
    return value


def prompt_credential(config=None, existing_credential=None, for_account=None, init_help=False):
    if not config:
        config = cyclecli.get_config()

    ds = cyclecli.get_datastore(config)

    if existing_credential is not None:
        modified_credential = copy.deepcopy(existing_credential)

        if for_account is not None:
            provider = for_account["Provider"] or "azure"
            modified_credential["AccountName"] = for_account["Name"]
        else:
            account_name = modified_credential["AccountName"]
            accounts = ds.find("Cloud.ProviderAccount", "Name === %s" % expressions.quote(account_name))
            if len(accounts) == 0:
                print("Account missing, unable to determine provider.")
                provider = None
            else:
                provider = accounts[0]["Provider"] or "azure"

    else:
        modified_credential = records.create("Credential")

        while True:
            modified_credential["Name"] = cyclecli.prompt("Credential Name: ", required=True)
            credential_name = modified_credential["Name"]
            if len(ds.find("Credential", "Name === %s" % expressions.quote(credential_name))) > 0:
                print("Credential name already in use, please provide a different name")
            else:
                break

        if for_account is not None:
            provider = for_account["Provider"] or "azure"
            modified_credential["AccountName"] = for_account["Name"]
        else:
            while True:
                modified_credential["AccountName"] = cyclecli.prompt("Account Name: ", required=True)
                account_name = modified_credential["AccountName"]
                accounts = ds.find("Cloud.ProviderAccount", "Name === %s" % expressions.quote(account_name))
                if len(accounts) == 0:
                    print("Account doesn't exist. If you want a new account use the add_account command.")
                else:
                    provider = accounts[0]["Provider"] or "azure"
                    break

    if not modified_credential["CredentialType"] and provider:
        if provider.lower() == "azure":
            modified_credential["CredentialType"] = "AzureRM"

    credential_type = modified_credential["CredentialType"]

    s = cyclecli.get_session(config)

    credential_check_params = {"format": "json"}
    credential_check_url = "%s/cycle/auth/credential/test/" % config["url"]

    print("In order to administer the cloud account we need credentials to authenticate to %s." % credential_type)

    while True:
        if credential_type.lower() == "azurerm":
            modified_credential["AzureRMSubscriptionId"] = cyclecli.prompt("Subscription Id: ", default_value=modified_credential["AzureRMSubscriptionId"], required=True)
            modified_credential["AzureRMTenantId"] = cyclecli.prompt("Tenant Id: ", default_value=modified_credential["AzureRMTenantId"], required=True)
            modified_credential["AzureRMApplicationId"] = cyclecli.prompt("Application Id: ", default_value=modified_credential["AzureRMApplicationId"], required=True)
            modified_credential["AzureRMApplicationSecret"] = cyclecli.prompt("Application Secret: ", default_value=modified_credential["AzureRMApplicationSecret"], required=True, password=True)
        else:
            raise UserError("Unable to edit credentials of this type")

        r = s.post(credential_check_url, data=json.dumps(modified_credential.get_dict()), params=credential_check_params)
        r.raise_for_status()
        valid_creds = json.loads(r.text)[0]["Success"]

        if valid_creds:
            break
        else:
            print("Invalid credentials, please try again.")

    if for_account is not None:
        if modified_credential["Default"] is True:
            default_credential = "y"
        else:
            default_credential = "n"

        modified_credential["Default"] = cyclecli.prompt("Is Default Credential: ", default_value=default_credential, valid_selections=YES_NO_SET) in YES_SET
    else:
        modified_credential["Default"] = True

    return modified_credential


class AccountCommand(BaseCommand):
    def __init__(self, application_name):
        self.args = "account <command>"
        self.description = "Manage cloud provider accounts."

        self.usage = '''
%s account <command> [options]

Valid commands are:
list                   list accounts
show <account_name>    show detail for an account
create                 create a new account
edit <account_name>    edit an existing account
delete <account_name>  delete an existing account
        ''' % application_name.lower()

    def configure(self, parser):
        parser.set_usage(self.usage.strip())
        parser.add_option("-o", dest="output_file",
                          help="For create/edit, writes the configuration parameters to disk")
        parser.add_option("--dry-run", action="store_true", dest="dryrun",
                          help="For create/edit, prompts and validates information but does not enact any changes")
        parser.add_option("-f", dest="input_file",
                          help="For create/edit, reads the definition from a configuration file instead of prompting")
        parser.add_option('--force', dest='force', help="For delete, if true, does not prompt to delete the account.",
                          action="store_true")

    def execute(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Missing expected argument!")

        command = arguments.pop(0)

        if command == "list":
            self._list(options, arguments)
        elif command == "show":
            self._show(options, arguments)
        elif command == "create":
            self._create(options, arguments)
        elif command == "edit":
            self._edit(options, arguments)
        elif command == "delete":
            self._delete(options, arguments)
        else:
            raise ArgumentError('Command provided "%s" is invalid' % command)

    def _list(self, options, arguments):
        if len(arguments) > 0:
            raise ArgumentError("Unexpected arguments specified!")

        ds = cyclecli.get_datastore()

        r = ds.find("Cloud.ProviderAccount")

        if len(r) == 0:
            print("No accounts found")
            return

        self._print_accounts(r)

    def _show(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Missing expected argument!")
        elif len(arguments) > 1:
            raise ArgumentError("Unexpected arguments specified!")

        account_name = arguments[0]

        ds = cyclecli.get_datastore()

        existing_account = ds.find("Cloud.ProviderAccount", "Name === %s" % expressions.quote(account_name))

        if len(existing_account) == 0:
            print("Account not found")
            return
        existing_account = existing_account[0]

        self._print_account(existing_account)

    def _print_accounts(self, records):
        for account in records:
            self._print_account(account, detailed=False)

    def _print_account(self, record, detailed=True):
        default_star = "*" if record["Default"] else ""

        print("%s %s" % (record["Name"], default_star))

        provider = record.get("Provider", "")
        print("  Provider: %s" % provider)

        print("  Master Credentials: %s" % record["MasterCredentials"])

        if detailed:
            account_name = record["Name"]

            ds = cyclecli.get_datastore()

            credentials = ds.find("Credential", "AccountName === %s" % expressions.quote(account_name))

            print("  ---- Credentials ----")
            for credential in credentials:
                print("  %s" % credential["Name"])

            # creds_expr = expressions.attributeIn("Credentials", [v.get("Name") for v in credentials])

            # lockers = ds.find("Cloud.Locker", creds_expr) todo - consider hidden records

            # print "  ---- Lockers ----"
            # for locker in lockers:
            #     print "  %s" % locker["Name"]

    def _create(self, options, arguments):
        if len(arguments) > 0:
            raise ArgumentError("Unexpected arguments specified!")
        cyclecloud.account.modify_account(dryrun=options.dryrun, input_file=options.input_file, output_file=options.output_file)

    def _edit(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Missing expected argument!")
        elif len(arguments) > 1:
            raise ArgumentError("Unexpected arguments specified!")

        account_name = arguments[0]

        ds = cyclecli.get_datastore()

        existing_account = ds.find("Cloud.ProviderAccount", "Name === %s" % expressions.quote(account_name))

        if len(existing_account) == 0:
            print("Account not found")
            return
        existing_account = existing_account[0]

        print("Editing account: %s" % existing_account["Name"])

        cyclecloud.account.modify_account(account_name=account_name, dryrun=options.dryrun, input_file=options.input_file, output_file=options.output_file)

    def _delete(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Missing expected argument!")
        elif len(arguments) > 1:
            raise ArgumentError("Unexpected arguments specified!")

        account_name = arguments[0]

        ds = cyclecli.get_datastore()

        existing_account = ds.find("Cloud.ProviderAccount", "Name === %s" % expressions.quote(account_name))

        if len(existing_account) == 0:
            print("Account not found")
            return

        confirmed = False
        if options.force:
            confirmed = True
        elif cyclecli.prompt("This will delete the account and all of its credentials and lockers, are you sure?",
                             default_value="n", valid_selections=YES_NO_SET) in YES_SET:
            confirmed = True

        if not confirmed:
            return

        delete_actions = ds.find("Application.Action", 'Name === "Delete:Cloud.ProviderAccount"')
        if delete_actions:
            config = cyclecli.get_config()
            s = cyclecli.get_session(config)

            params = {}

            r = s.post("%s/exec/action/Delete:Cloud.ProviderAccount/%s" % (config["url"], urlquote(account_name)), params=params)
            _raise_if_needed(r)
        else:
            policy = {CASCADE_DELETE_ATTR: "true"}
            ds.delete('Cloud.ProviderAccount', 'Name === %s' % expressions.quote(account_name), policy)


class CredentialCommand(BaseCommand):
    def __init__(self, application_name):
        self.args = "credential <command>"
        self.description = "Manage cloud provider account credentials."

        self.usage = '''
%s credential <command> [options]

Valid commands are:
list                   list credentials
create                 create a new credential
edit <account_name>    edit an existing credential
delete <account_name>  delete an existing credential
        ''' % application_name.lower()

    def configure(self, parser):
        parser.set_usage(self.usage.strip())

    def execute(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Missing expected argument!")

        command = arguments.pop(0)

        if command == "list":
            self._list(options, arguments)
        elif command == "show":
            self._show(options, arguments)
        elif command == "create":
            self._create(options, arguments)
        elif command == "edit":
            self._edit(options, arguments)
        elif command == "delete":
            self._delete(options, arguments)
        else:
            raise ArgumentError('Command provided "%s" is invalid' % command)

    def _list(self, options, arguments):
        if len(arguments) > 1:
            raise ArgumentError("Unexpected arguments specified!")

        ds = cyclecli.get_datastore()

        r = ds.find("Credential", "AccountName isnt Undefined")

        if len(r) == 0:
            print("No credentials found")
            return

        self._print_credentials(r)

    def _show(self, options, arguments):

        if len(arguments) == 0:
            raise ArgumentError("Missing expected argument!")
        elif len(arguments) > 1:
            raise ArgumentError("Unexpected arguments specified!")

        credential_name = arguments[0]

        ds = cyclecli.get_datastore()

        existing_credential = ds.find("Credential", "AccountName isnt Undefined && Name === %s" % expressions.quote(credential_name))

        if len(existing_credential) == 0:
            print("Credential not found or not bound to an account")
            return
        existing_credential = existing_credential[0]

        self._print_credential(existing_credential)

    def _print_credentials(self, records):
        for cred in records:
            self._print_credential(cred, detailed=False)

    def _print_credential(self, record, detailed=True):
        default_star = "*" if record["Default"] else ""

        print("%s %s" % (record["Name"], default_star))
        print("  Account: %s" % record["AccountName"])
        print("  Credential Type: %s" % record["CredentialType"])

        credential_type = record["CredentialType"]
        if credential_type.lower() == "azurerm":
            print("  Azure Subscription: %s" % record["AzureRMSubscriptionId"])

        # if detailed:
        #     credential_name = record["Name"]

        #     ds = cyclecli.get_datastore()

    def _create(self, options, arguments):
        if len(arguments) > 0:
            raise ArgumentError("Unexpected arguments specified!")

        ds = cyclecli.get_datastore()

        new_cred = prompt_credential()

        ds.save(new_cred)

    def _edit(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Missing expected argument!")
        elif len(arguments) > 1:
            raise ArgumentError("Unexpected arguments specified!")

        credential_name = arguments[0]

        ds = cyclecli.get_datastore()

        existing_credential = ds.find("Credential", "AccountName isnt Undefined && Name === %s" % expressions.quote(credential_name))

        if len(existing_credential) == 0:
            print("Credential not found")
            return
        existing_credential = existing_credential[0]

        print("Editing credential: %s" % existing_credential["Name"])
        modified_credential = prompt_credential(None, existing_credential)

        ds.save(modified_credential)

    def _delete(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Missing expected argument!")
        elif len(arguments) > 1:
            raise ArgumentError("Unexpected arguments specified!")

        credential_name = arguments[0]

        ds = cyclecli.get_datastore()

        existing_credential = ds.find("Credential", "AccountName isnt Undefined && Name === %s" % expressions.quote(credential_name))

        if len(existing_credential) == 0:
            print("Credential not found")
            return

        if cyclecli.prompt("Are you sure you want to delete this credential?", default_value="n", valid_selections=YES_NO_SET) in YES_SET:
            ds.delete('Credential', 'Name === %s' % expressions.quote(credential_name))


class ImageCommand(BaseCommand):
    def __init__(self, application_name):
        self.args = "image <command>"
        self.description = "Manage custom images."

        self.usage = '''
%s image <command> [options]

Valid commands are:
add <image_name> [...]     add one or more images
        ''' % application_name.lower()

    def configure(self, parser):
        parser.set_usage(self.usage.strip())
        parser.add_option("--account", dest="accounts", action="append",
                          help="For add, search only this account (can be repeated for multiple accounts)")
        parser.add_option("--name",
                          help="For add, the name of the package to create (required)")
        parser.add_option("--label",
                          help="For add, the label of the package to create")
        parser.add_option("--package-version", dest="package_version",
                          help="For add, use this version for the new image instead of the default of 1.0.0")
        parser.add_option("--bump-version", dest="bump_version",
                          help="For add, use '--bump-version minor' to increment the latest minor version by 1 (eg, 1.1 to 1.2), or use '--bump-version major' or '--bump-version patch'")
        parser.add_option("--os", dest="os",
                          help="For add, use '--os linux/windows' to specify the Operating System on the image")
        
        # Options for how to configure jetpack
        parser.add_option('--jetpack-version', dest="jetpack_version",
                         help="The version of jetpack that is installed or should be installed on the image")
        parser.add_option('--install-jetpack', dest='install_jetpack', action="store_true", default=False,
                         help="Install jetpack at runtime on this image")
        parser.add_option('--jetpack-platform', dest='jetpack_platform',
                         help="The jetpack platform used on the image (e.g. centos-7, ubuntu-14.04, windows")

        parser.add_option("--dry-run", action="store_true", dest="dryrun",
                          help="For add, looks for matching images but does not store any image information")
        

    def execute(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Missing expected argument!")

        command = arguments.pop(0)

        if command == "add":
            self._add(options, arguments)
        else:
            raise ArgumentError('Command provided "%s" is invalid' % command)

    def _add(self, options, arguments):
        config = cyclecli.get_config()

        name = arguments

        s = cyclecli.get_session(config)

        if options.name is None:
            raise ArgumentError("--name is required")

        if options.package_version and options.bump_version:
            raise ArgumentError("--package-version and --bump-version cannot be used together")

        if options.os is None:
            raise ArgumentError("--os is required")

        params = {}
        if options.bump_version:
            params["bump_version"] = options.bump_version
        if options.accounts:
            params["accounts"] = ",".join([urlquote(a) for a in options.accounts])
        if options.dryrun:
            params["dryrun"] = "true"
        if options.label:
            params["label"] = options.label
        if options.os:
            params["os"] = options.os
        if options.jetpack_version:
            params['jetpack_version'] = options.jetpack_version
        if options.jetpack_platform:
            params['jetpack_platform'] = options.jetpack_platform
        if options.install_jetpack:
            params['install_jetpack'] = "1"

        if not arguments:
            raise ArgumentError("No image ids given")

        image_ids = arguments
        params["image_ids"] = ",".join([urlquote(i) for i in image_ids])

        package = {}
        package["Name"] = options.name

        if options.package_version:
            package["Version"] = options.package_version

        params["package"] = json.dumps(package)

        r = s.post("%s/cloud/api/add_image" % (config["url"]), params=params)
        _raise_if_needed(r)

        summary = json.loads(r.text)

        matched_accounts = set()
        unmatched_images = set(image_ids)

        package = CaseInsensitiveDict(summary["Package"])

        artifact_map = summary["Artifacts"]
        for name, artifact_dict in artifact_map.items():
            artifact = CaseInsensitiveDict(artifact_dict)
            matched_accounts.add(artifact["AccountName"])
            unmatched_images.remove(name)

        values = []
        for image_id in image_ids:
            description = "** not found **"
            if image_id in artifact_map:
                artifact = artifact_map[image_id]
                if "Description" in artifact:
                    description = artifact["Description"]

            values.append([image_id, description])

        if matched_accounts:
            print()
            cyclecloud.util.print_table(values, headings=["Image name/id", "Description"])

            artifact_label = cyclecloud.util.pluralize(len(summary["Artifacts"]), "artifact")
            account_label = cyclecloud.util.pluralize(len(matched_accounts), "account")
            print()

            print("Added image %s, v%s with %s from %s (%s)" % (package["Name"], package["Version"],
                                                                artifact_label, account_label, ", ".join(matched_accounts)))
        else:
            print("Could not match any images")

        if unmatched_images:
            raise UserError("Could not match %s" % (cyclecloud.util.pluralize(len(unmatched_images), "artifact")))
        elif options.dryrun:
            print("Image not saved (--dry-run was specified)")


class ExportParametersCommand(BaseCommand):
    def __init__(self, application_name):
        self.args = "export_parameters <cluster_name>"
        self.description = "Export Parameters for a given cluster."

        self.usage = '''
%s export_parameters <cluster_name> [options]
        ''' % application_name.lower()

    def configure(self, parser):
        parser.set_usage(self.usage.strip())
        parser.add_option("-o", dest="output_file", default=None,
                          help="For create, writes the cluster parameters to disk")
        parser.add_option("--format", dest="output_format", default='json',
                          help="Output format")

    def execute(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Missing expected cluster_name!")
        cluster_name = arguments.pop(0)
        _export_params(cluster_name, options)


def _export_params(cluster_name, options, writer=sys.stdout):
    params = {"format": options.output_format}
    config = cyclecli.get_config()
    s = cyclecli.get_session(config)
    url = "%s/cloud/api/export_parameters/%s" % (config["url"], cluster_name)
    r = s.get(url, params=params)
    _raise_if_needed(r)
    if options.output_file:
        with open(options.output_file, 'w') as f:
            f.write(r.text)
    else:
        writer.write(r.text)


class CopyClusterCommand(BaseCommand):
    def __init__(self):
        self.args = "<source_cluster_name> <new_cluster_name>"
        self.description = "Makes a copy of a cluster."

    def configure(self, parser):
        parser.add_option("-p", "--parameters", dest="parameters",
                          help="The parameters file to use",
                          metavar="PARAMETERS",
                          default="")

    def execute(self, options, arguments):
        if len(arguments) != 2:
            raise ArgumentError("Two arguments are required, the source cluster name and the new cluster name ")

        config = cyclecli.get_config()
        name = arguments[0]
        new_cluster_name = arguments[1]

        print("Making a copy of cluster %s as cluster %s...." % (name, new_cluster_name))
        _copycluster(config, name, new_cluster_name, options)
        cyclecloud._showcluster(config, new_cluster_name, options)


def _copycluster(config, name, new_cluster_name, options):
    s = cyclecli.get_session(config)

    params = {"new_name": new_cluster_name}

    if options.parameters:
        params_file = os.path.expanduser(options.parameters)
        if not os.path.exists(params_file):
            raise ValueError("File %s not found" % params_file)

        with open(params_file) as f:
            parameters = f.read()

        params["parameters"] = parameters
        if params_file.endswith("json"):
            params["parameters_format"] = "json"
        elif params_file.endswith("properties"):
            # this format is a superset of the java properties format
            params["parameters_format"] = "informal"

    r = s.post("%s/cloud/api/copy_cluster/%s" % (config["url"], urlquote(name)), files=params)
    _raise_if_needed(r)


class ProjectCommand(BaseCommand):
    def __init__(self, application_name):
        self.args = "project <command>"
        self.description = "Manage CycleCloud projects."

        self.usage = '''
%s project <command> [options]

Valid commands are:
init <name>                create a new empty project
fetch <url> <path>         fetches a project from a Github <url> to <path>
info                       display project info
add_spec <spec>            adds a spec to the project
default_locker <locker>    sets the default locker(s) to upload to
test                       execute integration test for a given cluster definition
build                      build the project
upload [locker]            build and upload project the specified locker(s) (uses default if none specified)
download [locker]          download the project blobs from the specified locker(s) (uses default if none specified)
generate_template <file>   generate a cluster template for the project, written to <file>
        ''' % application_name.lower()

    def configure(self, parser):
        parser.set_usage(self.usage.strip())
        parser.add_option("--skip-teardown", dest='skip_teardown', help="For test, skip tearing down cluster created for testing", action="store_true", default=False)
        parser.add_option("--output-json", dest='json_file', help="For test, output the results to the specified json file")
        parser.add_option("--junit-xml", dest='junit_file', help="For test, output the results in junit-xml format to the specified json file")
        parser.add_option("-e", "--extra-var", dest='extra_vars', help="For test, arbitrary key=value pairs used to parameterize the cluster template under test", action="append")
        parser.add_option("-t", "--template", dest='template', help="For test, path to cluster template file")
        parser.add_option("-n", "--name", dest='cluster_name', help="For test, name of cluster definition to test")
        parser.add_option("--global", dest='global_setting', help="For default_locker, set global default instead of project specific value.", action="store_true")
        parser.add_option("--project-version", dest='project_version', default=None,
                          help='For build/upload, override the project version present in project.ini')
        parser.add_option('--build-dir', dest='build_dir', default=None, help="For build, the build directory")


    def execute(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Missing expected argument!")

        command = arguments.pop(0)

        if command == "init":
            self._init(options, arguments)
        elif command == "fetch":
            self._fetch(options, arguments)
        elif command == "info":
            self._info(options, arguments)
        elif command == "add_spec":
            self._add_spec(options, arguments)
        elif command == "default_locker":
            self._default_locker(options, arguments)
        elif command == "build":
            self._build(options, arguments)
        elif command == "upload":
            self._upload(options, arguments)
        elif command == "download":
            self._download(options, arguments)
        elif command == "test":
            self._test(options, arguments)
        elif command == "generate_template":
            self._generate_template(options, arguments)
        else:
            raise ArgumentError('Command provided "%s" is invalid' % command)

    def _init(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Missing expected argument!")

        name = arguments.pop(0)

        proj = projects.initialize(name, path=name, version="1.0.0")
        print("Project '%s' initialized in %s" % (name, os.path.abspath(name)))

        global_default, lockers = proj.get_default_lockers()
        if not global_default:
            if lockers:
                print("Project already has default lockers of: %s" % (", ".join(lockers)))

            if not lockers or cyclecli.prompt("Would you like to specify new default lockers? ", valid_selections=YES_NO_SET) in YES_SET:
                valid_lockers = False
                while not valid_lockers:
                    # NOTE: We normally handle using multiple lockers for upload/download/defaults
                    # But when initializing a project we simply ask for one since we get no type
                    # of shell based parsing here. Example is that we want to be able to take lockers
                    # with spaces in their names. If we really want to take multiple we can look
                    # at using the shlex library to parse quotes correctly.
                    locker = cyclecli.prompt("Default locker: ")
                    lockers = [locker]
                    try:
                        proj._validate_lockers(lockers)
                        valid_lockers = True
                    except:
                        pass

                proj.set_default_lockers(lockers)

    def _info(self, options, arguments):
        proj = projects.get_current_project()
        print(proj)

    def _fetch(self, options, arguments):
        if len(arguments) != 2:
            raise ArgumentError("Expected URL and PATH arguments!")

        projects.fetch_project(arguments[0], arguments[1])

    def _add_spec(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Missing expected argument!")
        spec = arguments.pop(0)

        proj = projects.get_current_project()
        proj.add_spec(spec)
        print("Spec %s added to project!" % spec)

    def _default_locker(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Missing expected argument!")

        proj = projects.get_current_project()
        proj._validate_lockers(arguments)

        if options.global_setting:
            projects.set_default_lockers(arguments)
        else:    
            proj.set_default_lockers(arguments)
            print(proj)

    def _build(self, options, arguments):
        proj = projects.get_current_project(version=options.project_version)
        proj.build(build_dir=options.build_dir)

    def _upload(self, options, arguments):
        proj = projects.get_current_project(version=options.project_version)
        success = proj.upload(arguments)

        print("")
        if success:
            print("Upload complete!")
        else:
            print("Upload failed!")

    def _test(self, options, arguments):
        params = cyclecloud.tests.convert_cli_options_to_test_params(options)

        if options.json_file is not None and options.junit_file is not None:
            raise Exception("You have specified both --output-json and --junit-xml. You can only specify one.")

        if options.cluster_name is None:
            raise Exception("Please specify the cluster name with --name")

        if options.template is None:
            raise Exception("Please specify the path to a file containing cluster templates with --template")
        cyclecloud.tests.test_project(cluster_name=options.cluster_name,
                                      template=options.template,
                                      skip_teardown=options.skip_teardown,
                                      params=params,
                                      output_json=options.json_file,
                                      output_junit=options.junit_file)

    def _download(self, options, arguments):
        proj = projects.get_current_project()
        success = proj.download(arguments)
        if success:
            print("Download complete!")
        else:
            print("Download failed!")

    def _generate_template(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Expected a file name to write the template to!")
        dest = arguments.pop(0)

        proj = projects.get_current_project()
        proj.generate_template(dest)
        print("Cluster template written to %s" % dest)


class LockerCommand(BaseCommand):
    def __init__(self, application_name):
        self.args = "locker <command>"
        self.description = "Manage CycleCloud lockers."

        self.usage = '''
%s locker <command> [options]

Valid commands are:
list               list lockers
show <locker>      show detail for a locker
        ''' % application_name.lower()

    def configure(self, parser):
        parser.set_usage(self.usage.strip())

    def execute(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Missing expected argument!")

        command = arguments.pop(0)

        if command == "list":
            self._list(options, arguments)
        elif command == "show":
            self._show(options, arguments)
        else:
            raise ArgumentError('Command provided "%s" is invalid' % command)

    def _list(self, options, arguments):
        if len(arguments) > 0:
            raise ArgumentError("Unexpected arguments specified!")

        ds = cyclecli.get_datastore()

        r = ds.find("Cloud.Locker", "Hidden!==true")

        if len(r) == 0:
            print("No lockers found")
            return

        self._print_lockers(r)

    def _show(self, options, arguments):
        if len(arguments) == 0:
            raise ArgumentError("Missing expected argument!")
        if len(arguments) > 1:
            raise ArgumentError("Unexpected arguments specified!")

        locker_name = arguments[0]

        ds = cyclecli.get_datastore()

        existing_locker = ds.find("Cloud.Locker", "Name === %s" % expressions.quote(locker_name))

        if len(existing_locker) == 0:
            print("Locker not found")
            return
        existing_locker = existing_locker[0]

        self._print_locker(existing_locker)

    def _print_locker(self, locker):
        print(locker["Name"])
        for attr in ["Provider", "Credentials", "Location", "Region"]:
            if locker.get(attr):
                print("  %s: %s" % (attr, locker[attr]))

    def _print_lockers(self, lockers):
        for locker in lockers:
            locker_str = locker["Name"]
            if "Location" in locker:
                locker_str += " (%s)" % locker["Location"]
            print(locker_str)


def _raise_if_needed(r):
    if 400 <= r.status_code < 500:
        if r.text:
            raise UserError(r.text)
        else:
            raise UserError("Unspecified Error (%s)" % r.status_code)

    r.raise_for_status()
