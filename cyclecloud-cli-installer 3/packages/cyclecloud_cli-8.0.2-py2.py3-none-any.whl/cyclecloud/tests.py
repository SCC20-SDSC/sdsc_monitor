import cyclecli
import uuid
import logging
import tempfile
import click
import json
import tryme
import cyclecloud.api
#import cyclecloud.projects
import xml.etree.ElementTree
from functools import reduce


logger = logging.getLogger(__name__)


def _split_extra_var(extra_vars, extra_var):
    try:
        key, var = extra_var.split('=')
    except ValueError:
        raise cyclecli.ArgumentError("Extra variables specified with '-e' must match the form '-e foo=bar'. %s is not valid" % extra_var)

    extra_vars[key] = var
    return extra_vars
    

def split_extra_vars(extra_vars):
    '''Turn a list of key=value pairs into a dictionary'''
    return reduce(_split_extra_var, extra_vars, {})


def generate_unique_cluster_name(cluster_name):
    '''Create a unique cluster name by appending 4 random hex digits'''
    id = uuid.uuid1()
    return "%s-%s" % (cluster_name, id.hex[0:4])


def convert_cli_options_to_test_params(options):
    '''Convert cli options for the `cyclecloud project test` subcommand to a dict of parameters'''
    extra_vars = {}
    if options.extra_vars is not None:
        extra_vars = split_extra_vars(options.extra_vars)

    params = {}
    params.update(extra_vars)
    return params


@tryme.retry(delay=1, timeout=10)
def find_active_testrun(ds, cluster_name):
    found_testruns = ds.find('Cloud.TestRun', '(ClusterName=="%s") && (Active==True)' % cluster_name)
    if len(found_testruns) < 0:
        return tryme.Failure('no test runs found for cluster %s' % cluster_name)
    elif len(found_testruns) == 1:
        return tryme.Success(found_testruns[0])
    else:
        raise RuntimeError("Found more than one active testruns for %s. This is undefined behavior. Bailing out!" % cluster_name)


def start_cluster_in_test_mode(config, ds, cluster_id, cluster_def, params):
    '''
    Starts a cluster in test_mode
    params:
       config - cyclecloud config
       ds - instance of cyclecli.RestDatastore
       cluster_id - name of cluster to be started, typically has a randomly generated suffix 
                    to differentiate it from the actual clustername
       cluster_def - an instance of ClusterDefinition
       params - dictionary of parameters for the uploaded cluster template

    returns: uuid for TestRun
    '''
    with tempfile.NamedTemporaryFile(suffix='.json') as paramsfile:
        paramsfile.write(json.dumps(params))
        paramsfile.flush()
        cyclecloud.api.import_cluster(config, cluster_id, cluster_def.name,
                                      config_file=cluster_def.template, parameters=paramsfile.name)

    cyclecloud.api.start_cluster(config, cluster_id, test_mode=True)


def filter_out_instance_array_entries(nodes):
    # filter out instance array entries
    # which never enter the 'Ready' state
    nodes_to_remove = []
    for n in nodes:
        if n.get('IsArray', False) is True:
            nodes_to_remove.append(n)
    for n in nodes_to_remove:
        nodes.remove(n)

    return nodes


def find_nodes(ds, cluster_name):
    return filter_out_instance_array_entries(ds.find('Cloud.Node', 'ClusterName=="%s"' % cluster_name))


def writefile(filename, text):
    with open(filename, 'w') as f:
        f.write(text)


class TestSession(object):
    '''This generically represents a TestSession report whether it is in json or xml format'''
    def __init__(self, response_text, report_format):
        self.report_format = report_format
        if self.report_format == 'json':
            self._testsession = json.loads(response_text)
            self.outcome = self._testsession['Outcome']
            self.message = self._testsession.get('Message')
            self.duration = self._testsession.get('Summary', {}).get('duration')
        else:
            self._testsession = xml.etree.ElementTree.fromstring(response_text)
            self.outcome = self._testsession.attrib['outcome']
            self.message = self._testsession.attrib.get('message')
            self.duration = self._testsession.attrib.get('duration')

    def to_string(self):
        if self.report_format == 'json':
            return json.dumps(self._testsession, indent=4, sort_keys=True)
        else:
            # We have to strip out the <testrun> element as it is not valid junit-xml
            return xml.etree.ElementTree.tostring(self._testsession.find('testsuites'))


# These are "terminal" states where a given node will not change its state
# unless the user takes an action
NODE_TERMINAL_STATUSES = ['Ready', 'Terminated', 'Off', 'Failed']


@tryme.retry(delay=3, timeout=2400)
def get_testsession_result(config, session, cluster_name, report_format):
    plugin_url = '%s/cloud/api/testsession/%s' % (config['url'], cluster_name)
    
    response = session.get(plugin_url, params={'format': report_format})
    testsession = TestSession(response.text, report_format)
    
    if testsession.outcome is None:
        return tryme.Failure("Received invalid response from %s. Response status code is %d. Response body is %s"
                             % (plugin_url, response.text, response.status_code))
    
    if testsession.outcome == 'notready':
        return tryme.Failure(testsession)
    else:
        return tryme.Success(testsession)


@tryme.retry(timeout=(60 * 3))
def wait_for_cluster_terminated(ds, cluster_name):
    clusters = ds.find('Cloud.Cluster', 'ClusterName=="%s"' % cluster_name)
    if len(clusters) < 1:
        raise RuntimeError("No Cluster to terminate with name %s" % cluster_name)
    c = clusters[0]
    
    if c['Status'] == 'Terminated':
        return tryme.Success("Cluster %s finished terminating" % cluster_name)
    else:
        return tryme.Failure("Cluster %s not terminated after {total_time}" % cluster_name)


def destroy_cluster(config, ds, cluster_id):
    cyclecloud.api.terminate_cluster(config, cluster_id)

    result = wait_for_cluster_terminated(ds, cluster_id)
    # return early if failed during termination
    if result.failed():
        return result
    
    try:
        cyclecloud.api.delete_cluster(config, cluster_id, force=True)
        return tryme.Success("Succeeded in deleting cluster")
    except Exception as e:
        return tryme.Failure(e.message)


# def test_project(cluster_name, template, skip_teardown=False,
#                  params={}, output_json=None, output_junit=None):
#     '''
#     Run the integration tests for the given cluster_name in the current project. If no cluster_name
#     is given, run integration tests for the default cluster if that is not ambiguous
#     params:
#        cluster_name - name of cluster
#        template - cluster template file to use
#        locker - locker to upload project to. If None, upload to all lockers specified in project.ini
#        skip_upload - skip uploading project to a locker
#        skip_teardown - skip terminating and deleting created cluster
#        params - dictionary of parameters to be interpolated in the cluster template definition
#        output_json - write result of test run to this file
#        output_junit - write result of test run to this file in junit-xml format
#     '''
#     config = cyclecli.get_config()
#     session = cyclecli.get_session(config)
#     ds = cyclecli.datastore.RestDatastore(config['url'], session)

#     if output_junit is not None:
#         report_format = 'xml'
#     else:
#         report_format = 'json'
    
#     proj = cyclecloud.projects.get_current_project()
    
#     cluster_def = proj.get_cluster_definition(template, cluster_name)
#     cluster_id = generate_unique_cluster_name(cluster_def.name)
    
#     start_cluster_in_test_mode(config, ds, cluster_id, cluster_def, params)
#     click.echo("Started test session for cluster %s" % cluster_id)
    
#     result = get_testsession_result(config, session, cluster_id, report_format)
    
#     if skip_teardown:
#         click.echo("Skipping teardown")
#     else:
#         destroy_result = destroy_cluster(config, ds, cluster_id)
#         destroy_result.raise_for_error()

#     if result.failed():
#         raise Exception("The cluster never converged within timeout of %d seconds" % result.elapsed)

#     testrun = result.get()
    
#     click.echo(testrun.message)

#     if output_json is not None:
#         writefile(output_json, testrun.to_string())

#     if output_junit is not None:
#         writefile(output_junit, testrun.to_string())
